# 14. DevOps — отчёт

Роль: DevOps. Входы: `12_plan.md` (§5.2, §8), `12_tasks.md`, `12_arch_decision.md`, `10_constitution.md`, `12_approval_log.md` (архитектура согласована 2026-10-14).

## Статус задач

| ID | Задача | Статус | Доказательство |
|---|---|---|---|
| T001 | Каркас репозитория и команд | **Готово** в рамках среды: `make test` и `make test-unit` дают exit 0 без Docker. Docker-цели написаны, но не запускались: Docker Hub недоступен | Вывод ниже |
| T088 | SDL-проверки | **Готово (2026-10-21)**, Trivy — НЕ ПРОВЕРЕНО (только CI) | Раздел «2026-10-21» ниже |
| T087 | Полная поставка | **Проверено локально** (`[ ]` до журнала CI) | Раздел «2026-10-21» ниже |
| T092 | CI GitHub Actions | **Прогон `eb17642`: test — PASS, delivery — FAIL на up/smoke (вероятно 4Д6)**; добавлены аннотации (`[ ]` до релизного SHA) | Раздел «пакет 4» ниже |
| T090 | Руководство администратора | **Готово к приёмке** (`[ ]` до приёмки техлидом и прогона QA) | `docs/admin-guide.md` |

Оговорка: T088 зависит только от T001, поэтому сделан сразу. npm-часть заработает на реальном фронтенде после T002, Trivy — после T087 (образ) и установки trivy.

---

## T001

### Что сделано (файлы)

| Файл | Назначение |
|---|---|
| `Makefile` | Единая точка входа. Цели: `help`, `sync`, `test-unit`, `test`, `lint`, `fmt`, `lint-imports`, `check`, `egress-host-check`, `test-docker`, `build`, `up`, `down`, `logs`, `smoke`, `clean`. Цели `backup`, `restore`, `load`, `failover`, `e2e` пока завершаются с exit 2 и сообщением «ещё не реализовано» (T086, T087, QA) |
| `deploy/run-tests.sh` | Общий прогон тестов локально и в контейнере. Режим `unit`: pytest `tests/unit` + vitest. Режим `full`: проверка БД, pytest (`unit`, `contract`, `integration`, `acceptance`, `security`), import-linter, vitest |
| `app/backend/pyproject.toml`, `app/backend/uv.lock` | Пакет `bm`, Python `>=3.13,<3.14`. Прямые зависимости закреплены точно, extra `mcp`, группа `dev`, настройки ruff. В lock-файле 69 пакетов |
| `app/backend/importlinter.ini` | 3 контракта: httpx импортирует только `bm.egress` (принцип IV); `bm.domain` чистый (без БД, сети, фреймворков и других модулей `bm`); ядро не импортирует адаптеры `http`, `mcp`, `worker` |
| `app/backend/bm/__init__.py` + `__init__.py` подпакетов из `12_plan.md` §5.2 | Скелет пакетов. Он нужен import-linter: контракт по несуществующему модулю падает с ошибкой |
| `deploy/Dockerfile` | Стадии `python-base` (uv 0.11.32 из PyPI), `python-deps` (`uv sync --frozen --no-dev`), **`python-runtime`** (без uv, пользователь `bm` uid 10001, `HEALTHCHECK` на `/healthz`, `uvicorn bm.main:create_app --factory`), `tests` (для `make test-docker`) |
| `deploy/docker-compose.test.yml` | Сервисы `postgres-test` (`postgres:18`, tmpfs, healthcheck, `fsync=off`) и `tests` (`depends_on: service_healthy`). Сеть `internal: true` |
| `deploy/.env.example` | Все 25 переменных из `12_plan.md` §8 с комментариями. Секреты пустые: без них сервис не стартует |
| `tests/conftest.py` | Пустой, с описанием фикстур, которые добавит T014 |
| `tests/{unit,contract,integration,acceptance,security,smoke}/.gitkeep` | Каталоги, которые читает `make test` |
| `pytest.ini` (корень) | `testpaths=tests`, `pythonpath=.`, `--import-mode=importlib`, `asyncio_mode=auto`, `--strict-markers`, маркер `db` |
| `.gitignore`, `.dockerignore` | `.env`, `node_modules`, `__pycache__`, `.venv`, кэши, `deploy/ci/out/`. `.dockerignore` пропускает в контекст сборки только нужное (белый список) |

### Как запустить

```bash
make test-unit                      # без БД и Docker
make test                           # локальный PostgreSQL; по умолчанию DATABASE_URL=postgresql://postgres@127.0.0.1:5433/bm_test
make test DATABASE_URL=postgresql://user@host:5432/my_test_db
make lint                           # ruff + import-linter
make test-docker                    # то же в контейнере против чистого postgres:18 (нужен доступ к Docker Hub или зеркалу)
```

Защита от ошибки: `make test` отказывается работать, если в имени БД нет `test` (exit 2). Фикстура T014 будет пересоздавать схему, и случайный прогон по рабочей базе её бы стёр. Обойти можно явно: `ALLOW_ANY_TEST_DB=1`.

### Проверка (вывод команд)

`make test-unit`:
```
uv sync --project app/backend --frozen --all-extras
Checked 66 packages in 0.98ms
bash deploy/run-tests.sh unit
=== pytest tests/unit ===
platform linux -- Python 3.13.16, pytest-9.1.1, pluggy-1.6.0
rootdir: /home/claude/product_farm/projects/pf-20261013-llm-budget-manager
configfile: pytest.ini
plugins: asyncio-1.4.0, anyio-4.15.1
collected 0 items
============================ no tests ran in 0.01s =============================
pytest: тесты не найдены (exit 5) — для каркаса это допустимо, считаем успехом
=== frontend ===
vitest: нет app/frontend/package.json (фронтенд появится в T002) — пропуск
run-tests.sh unit: OK
EXIT make test-unit = 0
```

`make test` (локальный PostgreSQL 16.15, порт 5433):
```
=== БД ===
БД доступна: PostgreSQL 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
ВНИМАНИЕ: целевая версия PostgreSQL 18 (12_plan.md), тестовая — 16. Не используйте возможности только PG 18, пока стенд не обновлён.
=== pytest ===
collected 0 items
============================ no tests ran in 0.02s =============================
pytest: тесты не найдены (exit 5) — для каркаса это допустимо, считаем успехом
=== import-linter ===
httpx импортирует только bm.egress KEPT
bm.domain не зависит от ввода-вывода и других модулей bm KEPT
ядро не импортирует адаптеры (http, mcp, worker) KEPT
Contracts: 3 kept, 0 broken.
=== frontend ===
vitest: нет app/frontend/package.json (фронтенд появится в T002) — пропуск
run-tests.sh full: OK
EXIT make test = 0
```

Отрицательные проверки: цели должны падать, когда есть проблема.
```
--- имя БД без test (DATABASE_URL=.../postgres)
ОТКАЗ: имя БД 'postgres' не содержит 'test'. Тесты пересоздают схему; укажите тестовую БД.   exit=2
--- БД недоступна (порт 5999)
БД недоступна: ConnectionRefusedError: [Errno 111] Connect call failed ('127.0.0.1', 5999)      exit=2
--- временный падающий тест tests/unit/test_zz_red.py (assert 1 == 2), make test-unit
1 failed in 0.03s                                                                                exit=2
--- тот же файл с assert 1 == 1, make test
БД доступна: PostgreSQL 16.15 ... / 1 passed in 0.03s / run-tests.sh full: OK                    exit=0
--- import-linter: временный `import httpx` в bm/http/__init__.py
httpx импортирует только bm.egress BROKEN / Contracts: 2 kept, 1 broken.                         exit=1
```
Временные файлы удалены после проверки.

`make lint`:
```
Contracts: 3 kept, 0 broken.
ruff check ... All checks passed!
ruff format --check ... 18 files already formatted
EXIT make lint = 0
```

Docker-цели в этой среде не проверены: pull с Docker Hub запрещён.
```
$ docker compose -f deploy/docker-compose.test.yml config --quiet      → exit=0 (файл валиден)
$ make build
ERROR: failed to build: failed to solve: python:3.13-slim: failed to resolve source metadata for docker.io/library/python:3.13-slim: ... Forbidden
$ make test-docker
Error response from daemon: failed to resolve reference "docker.io/library/postgres:18": ... Forbidden
```

### Отклонения от плана и почему

1. **`make test` работает без Docker.** По §8 плана `make test` — это `docker compose ... run --rm tests`. Здесь Docker Hub недоступен, поэтому `make test` идёт на локальном PostgreSQL через `DATABASE_URL`, а прогон в контейнере вынесен в `make test-docker`. Оба вызывают один и тот же `deploy/run-tests.sh full`, так что набор проверок совпадает. Если техлид захочет, чтобы `make test` по умолчанию шёл в Docker, — это перестановка двух целей.
2. **PostgreSQL 16 вместо 18 на локальном стенде.** `make test` печатает предупреждение. Совместимость сохраняем: в DDL T014 не использовать то, что есть только в PG 18 (например, `uuidv7()` — [Вывод: функция появилась в PG 18], генерировать UUID v7 в приложении). В `docker-compose.test.yml` и CI — `postgres:18`.
3. **openapi-spec-validator: 0.8.5 вместо 0.9.0.** openapi-core 0.23.1 требует `openapi-spec-validator>=0.8.0,<0.9.0` [Факт: метаданные PyPI]. В pyproject стоит диапазон `>=0.8,<0.9`, точную версию фиксирует uv.lock. **Для T015:** у openapi-core 0.23.1 extra `fastapi` требует `fastapi<0.140` [Факт: метаданные PyPI], а мы закрепили 0.143.0. Значит, интеграцию openapi-core с FastAPI не используем: проверяем ответ через базовый API openapi-core, хелпер `assert_matches_contract` пишем сами.
4. **Exit 5 у pytest («тестов нет») считается успехом** в `run-tests.sh`. Иначе T001 не выполнить: «0 тестов и exit 0». Как только появятся тесты, это правило перестанет срабатывать.
5. **Добавлены файлы вне списка T001:** `pytest.ini` в корне (тесты лежат в корневом `tests/`, а venv — в `app/backend`), `.dockerignore`, `deploy/run-tests.sh`, скелет `__init__.py` подпакетов `bm` (нужен import-linter).
6. **Контракт egress — типа `forbidden`, а не `protected`.** `protected` падает, пока httpx никто не импортирует. Модули верхнего уровня `bm.main` и `bm.settings` в контракт не внесены, потому что их ещё нет. **Для T015:** добавить их в `source_modules` контракта `egress-only`.
7. **Образы закреплены по тегу (`python:3.13-slim`, `postgres:18`), а не по digest.** Получить digest без доступа к реестру нельзя. Перенос на `@sha256:` — в T087. Версии с полным patch-уровнем (`3.13.16-slim`, `18.6`) не проверены: Docker Hub API недоступен.
8. **Директива `# syntax=docker/dockerfile:1` удалена.** Она тянет frontend BuildKit с Docker Hub и в закрытом контуре сломала бы сборку.

### Версии (проверены по PyPI 2026-10-14)

[Факт] fastapi 0.143.0 (MIT), asyncpg 0.32.0 (Apache-2.0), mcp 2.3.0 (MIT), uvicorn 0.54.0, pydantic 2.14.1, pydantic-settings 2.15.0, httpx 0.28.1, argon2-cffi 25.1.0, prometheus-client 0.26.0, tzdata 2026.5. Dev: pytest 9.1.1, pytest-asyncio 1.4.0, openapi-core 0.23.1, openapi-spec-validator 0.8.5, import-linter 2.15, ruff 0.17.0. Инструменты: uv 0.11.32, Python 3.13.16, Node 22.22.0 / npm 10.9.4 в среде. По плану нужен Node 24 LTS: зафиксировать в T002 и T087.

---

## T088

### Что сделано

| Файл | Назначение |
|---|---|
| `deploy/ci/check.sh` | `make check`, шаги по порядку. (1) Окружение поставки: `uv sync --frozen --no-dev --all-extras`. (2) SBOM CycloneDX для Python (`cyclonedx-bom` 7.5.0). (3) Лицензии. (4) pip-audit 2.10.1 по экспортированному из uv.lock `requirements` с хэшами. (5) import-linter. (6) npm: запрет `@react-admin/ra-*` в lock-файле, SBOM (`@cyclonedx/cyclonedx-npm` 6.0.1), лицензии, `npm audit --omit=dev --audit-level=critical`. (7) Trivy: SBOM образа и `--severity CRITICAL --exit-code 1`. Сводка — `deploy/ci/out/summary.txt` |
| `deploy/ci/check_licenses.py` | Проверка лицензий по SBOM CycloneDX (Python и npm), только stdlib. Разбирает SPDX-выражения (OR, AND, WITH). Категории нарушений: COPYLEFT (GPL, AGPL, LGPL, SSPL), ENTERPRISE (`@react-admin/ra-*`, исключения на них не действуют), UNKNOWN, NOT_ALLOWED |
| `deploy/ci/licenses-allow.txt` | Список из T088 и дополнительно **MIT-0** (у `cffi`). Подтвердить у юриста |
| `deploy/ci/licenses-exceptions.txt` | **`pypi:certifi` (MPL-2.0)**: транзитивная зависимость httpx. Требует решения техлида и юриста, см. «Открытые вопросы» |
| `deploy/ci/vuln-ignore.txt` | Принятые уязвимости для pip-audit. Пока пусто |
| `deploy/ci/egress-host-check.sh` | `make egress-host-check`. Работает так: цепочка `BM_EGRESS` из `DOCKER-USER` для IP контейнеров compose-проекта; частные сети пропускаются; счётчик пакетов во внешние адреса считается во время `make smoke`; ожидается 0; правила снимаются через `trap` |

Режим `CHECK_STRICT=1` (для CI и релиза): любой пропущенный шаг считается ошибкой.

### Проверка (вывод команд)

`make check`:
```
=== Python: лицензии ===
deploy/ci/out/sbom-python.cdx.json: компонентов 40, нарушений 0
Исключения (deploy/ci/licenses-exceptions.txt): pypi:certifi
ЛИЦЕНЗИИ: OK
=== Python: уязвимости (pip-audit) ===
No known vulnerabilities found
pip-audit: пакетов 40, уязвимостей 0
...
=== Итог make check ===
OK    python: uv sync --frozen (lock-файл согласован)
OK    python: SBOM deploy/ci/out/sbom-python.cdx.json
OK    python: лицензии по белому списку
OK    python: pip-audit — известных уязвимостей нет
OK    python: import-linter
SKIP  npm: нет app/frontend/package.json (появится в T002)
SKIP  trivy: не установлен
make check: OK (SBOM и отчёты — deploy/ci/out/)
EXIT make check = 0
```

Отрицательные проверки:
```
--- без файла исключений
  NOT_ALLOWED  pypi:certifi@2026.7.22  [MPL-2.0]
ЛИЦЕНЗИИ: FAIL (1 нарушений)                                   exit=1
--- синтетический SBOM (GPL-3.0-only; MIT OR GPL-2.0-only; MIT AND LGPL-2.1-only; @react-admin/ra-rbac; без лицензии; классификатор MIT; SSPL-1.0)
  COPYLEFT     pypi:a@1  [GPL-3.0-only]
  COPYLEFT     pypi:c@1  [MIT AND LGPL-2.1-only]
  ENTERPRISE   npm:@react-admin/ra-rbac@5  [SEE LICENSE IN LICENSE.md]
  UNKNOWN      npm:d@1  [-]
  COPYLEFT     npm:f@1  [SSPL-1.0]
ЛИЦЕНЗИИ: FAIL (5 нарушений)                                   exit=1
  («MIT OR GPL-2.0-only» и классификатор MIT пропущены — так и задумано)
--- CHECK_STRICT=1 make check
FAIL  npm: нет app/frontend/package.json (появится в T002) (пропуск запрещён: CHECK_STRICT=1)
FAIL  trivy: не установлен (пропуск запрещён: CHECK_STRICT=1)
make check: FAIL                                               exit=1
```

npm-ветка проверена на пробном проекте вне репозитория (`FRONTEND_DIR=<scratch>`, зависимость `ms@2.1.3`):
```
OK    npm: нет @react-admin/ra-*
OK    npm: SBOM deploy/ci/out/sbom-npm.cdx.json
OK    npm: лицензии по белому списку
OK    npm: audit — критичных уязвимостей нет
make check: OK                                                 exit=0
```
Артефакты пробного прогона из `deploy/ci/out/` удалены.

### Что не проверено и почему

- **Trivy.** Бинарника нет в среде, а релизы на GitHub из сессии недоступны. Образа тоже нет: Docker Hub закрыт. Код шага написан, но не запускался.
- **`egress-host-check`.** Нужны root, iptables, поднятый стек (T087) и `make smoke`. Не запускался.
- **В закрытом контуре** `uvx` и `npx` берут инструменты из локального кэша. Кэш нужно прогреть заранее или поставить инструменты в образ сборки — это сделать в T087 вместе с офлайн-поставкой.
- **Покрытие SDL (ГОСТ Р 56939 / реестр).** Закрыто: SBOM Python, SCA (pip-audit), лицензионный контроль, архитектурные контракты, воспроизводимость по lock-файлам. Не закрыто: SBOM npm и образа (после T002 и T087), Trivy, статический анализ безопасности кода (сейчас только правила `S` (bandit) в ruff), поиск секретов (gitleaks), CI-пайплайн `.github/workflows/ci.yml`.

## Открытые вопросы для техлида

1. **certifi (MPL-2.0)** приходит через httpx. Варианты: (а) принять исключение — файловый копилефт, пакет не модифицируется; MPL-2.0 есть в белом списке `engineering-standards`, но не в списке T088; (б) убрать certifi из образа и использовать системное хранилище сертификатов — это решение backend по `bm.egress`. Сейчас действует (а), до решения техлида и юриста.
2. **MIT-0** добавлен в белый список (`cffi`). Нужно подтверждение.
3. **CI (`.github/workflows/ci.yml`)** в T001 и T088 не входит, и ни одной задачи с ним в `12_tasks.md` нет. Версии GitHub Actions проверить из сессии не удалось: API GitHub закрыт. Предлагаю отдельную задачу для DevOps: `make lint`, `make test` (service `postgres:18`), `CHECK_STRICT=1 make check`, gitleaks, SBOM как артефакт.
4. **Для T015:** добавить `bm.main` и `bm.settings` в контракт `egress-only`; не использовать extra `openapi-core[fastapi]` (несовместим с fastapi 0.143.0).
5. **Для T014:** DDL должен работать на PostgreSQL 16 (локальный стенд) и на 18 (поставка), либо локальный стенд нужно обновить.


---

## 2026-10-21 — T087, T092, T088, T090 (пакет 3, 3Д1–3Д4)

Среда: Docker 29.8.2 / Compose 5.5.1, демон запущен, все реестры отвечают 403. PostgreSQL 16.15. Node 22.22.0.

### Итог

| ID | Отметка | Статус гейтов (3Д2) |
|---|---|---|
| T087 | `[ ]`, проверено локально | статика compose — **PASS**; `up/smoke/backup/restore/smoke` — **PASS-замена** (стек из локальных процессов); сборка образа и стек в Docker — **НЕ ПРОВЕРЕНО** (реестры 403, проверка — CI T092 или чек-лист admin-guide §14) |
| T092 | `[ ]` | workflow написан, `actionlint` 0 ошибок; **прогона нет** — журнала CI нет, все его пункты НЕ ПРОВЕРЕНО |
| T088 | **`[x]`** | SBOM Python/npm, лицензии, pip-audit, npm audit, import-linter — **PASS**; Trivy — **НЕ ПРОВЕРЕНО** (нет бинарника и образа; шаг выполняется в CI) |
| T090 | `[ ]` | документ готов; ждёт приёмки техлида и прогона QA на чистой машине |

`make test` (полный, БД `bm_test_devops` на общем кластере 5432): **721 passed, 1 xfailed; frontend 28 файлов / 363 теста passed; exit 0.**

### Что сделано (файлы)

| Файл | Что |
|---|---|
| `deploy/docker-compose.yml` | `api`, `worker`, `postgres:18` (`bm`/`bm`), `backup`. Сеть `core` с `internal: true` (в ней `postgres`, `backup`), `edge` (у `api`, `worker`). Порт `"${BIND_ADDR}:${API_PORT}:8080"`. Healthcheck и `restart: unless-stopped` у всех сервисов. Секреты — compose `secrets` с источником `environment`: значения из `deploy/.env` попадают в контейнер файлами `/run/secrets/*` и читаются через `*_FILE`. Принцип наименьших прав: ключи провайдеров есть только у `worker`, пароль первого администратора — только у `api`. `DATABASE_URL` без пароля. `PROMETHEUS_MULTIPROC_DIR=/run/bm-metrics` на tmpfs (uid 10001), только у `api`. `IMPORT_HTTPS_PROXY` — только у `worker` (импорт выполняет он; `runImport` в `api` ставит задачу в очередь) |
| `deploy/Dockerfile` | Стадия `node-build` (`npm ci` + `npm run build` + check-dist, `design/tokens.json`) → `COPY dist /app/static/admin`. Добавлены entrypoint и `healthcheck.py`. `UV_EXTRAS` и `--all-extras` убраны |
| `deploy/docker-entrypoint.sh` | Снимает `*_FILE`, если файла нет. Пустой секрет compose файлом не создаёт [Факт: проверено на образе-заглушке, см. ниже]. Пароль БД из `POSTGRES_PASSWORD_FILE` передаёт в `PGPASSWORD` (asyncpg берёт его, если в DSN нет пароля [Факт: asyncpg 0.32 `connect_utils.py`]). Очищает каталог метрик при старте |
| `deploy/healthcheck.py` | `api`: `/readyz`. `worker`: PID 1 — это `bm.worker`, и `SELECT 1` к БД |
| `deploy/backup/{backup.sh,restore.sh}` | `pg_dump -Fc` во временный файл, проверка `pg_restore --list`, ротация `BACKUP_KEEP`, `--loop` (раз в сутки), `--healthcheck` (копия не старше 26 ч). Восстановление — в чистую БД: `DROP DATABASE … WITH (FORCE)` → `CREATE` → `pg_restore --exit-on-error` |
| `deploy/local/stack.sh` | Стек из локальных процессов: свой кластер PG (initdb, порт 55432, только TCP 127.0.0.1, `bm`/`bm`, данные в `deploy/local/.state/` в `.gitignore`), `api` (uvicorn, 2 воркера, порт 18080), `worker`. Pid-файлы, каждый сервис в своей сессии (pid = pgid). `stop` = сигнал остановки (у postgres SIGINT, как STOPSIGNAL официального образа [Вывод]; у api/worker SIGTERM) → до 10 с → SIGKILL группы. `kill` = SIGKILL группы. Команды `up/down/destroy/status/start/stop/kill/wait/env/backup/restore/logs`. Порт 5432 запрещён явно |
| `Makefile` | `up-local`, `down-local`, `backup`, `restore` (compose и `BM_STACK=local`), `compose-check`. `smoke` и `failover` при `BM_STACK=local` берут переменные из `stack.sh env`. `lint`/`fmt` по `app/backend app/client tests deploy` (3Б9). `--all-extras` убран. Compose вызывается через `env -u DATABASE_URL`: экспорт тестового `DATABASE_URL` из Makefile иначе подменял бы `DATABASE_URL` стека (дефект найден тестом, см. ниже). `load e2e` переставлены в `e2e load`: строка, начинающаяся с `load`, — директива GNU make |
| `deploy/.env.example` | `SESSION_COOKIE_SECURE=false` и `IMPORT_HTTPS_PROXY=` с комментариями по Б2/Б4. Описано, как передаются секреты. `DATABASE_URL` без пароля. Пары `*_ADMIN_KEY_FILE` убраны (в compose это файлы `/run/secrets`). `BM_ADMIN_PASSWORD` — только для smoke и failover |
| `app/backend/pyproject.toml`, `uv.lock` | Extra `mcp` удалён (3К): из lock ушли 10 пакетов (mcp, mcp-types, httpx2, httpcore2, httpx2-jsfetch, sse-starlette, pyjwt, cryptography, truststore, pywin32). **certifi 2026.7.22 → 2026.10.19** — см. отклонение 1 |
| `tests/smoke/{conftest.py,test_smoke.py}` | healthz, readyz, metrics; ключевой сценарий: вход (при первом входе — смена временного пароля на `BM_ADMIN_PASSWORD`) → модель, подразделение, лимит, ключ → `allow` → отчёт 100,00 ₽ → остаток уменьшился ровно на сумму отчёта. `compose_only`: SPA `/admin/`, все 4 сервиса healthy, uid 10001, каталог метрик только у `api`, порт `postgres` не опубликован. Без `BM_SMOKE=1` тесты пропускаются; с ним при отсутствии стека — падают |
| `tests/deploy/test_compose_static.py` | Статические требования 3Д1(а) по `docker compose config --format json`, `.env.example`, Dockerfile, удалению MCP. Входит в `make test`. `BM_REQUIRE_COMPOSE=1` (CI) запрещает пропуск |
| `tests/deploy/test_check_licenses.py`, `deploy/ci/check_licenses.py`, `licenses-exceptions.txt` | Исключения только вида `<тип>:<имя>@<версия>` (3Д3). Запись без версии — exit 2. На копилефт исключения не действуют. Исключения: `pypi:certifi@2026.10.19`, `unknown:budget-client@0.1.0` (собственный клиент без purl) |
| `deploy/ci/check.sh` | Окружение поставки без extras плюс `budget_client` (3Б9). Команда Trivy задаётся через `TRIVY` (в CI — контейнер). Строка лицензии `@tanstack/react-query` из npm-SBOM (3Ф3) |
| `.github/workflows/ci.yml` | Задача `test`: сервис `postgres:18`, `make lint`, `make compose-check`, `make test`, фронтенд в `node:24-slim`. Задача `delivery`: `make build`, digest базовых образов, `make up && make smoke && make backup && make restore && make smoke`, `make failover`, `CHECK_STRICT=1 make check` с Trivy в контейнере, попытка `sudo make egress-host-check` (`continue-on-error`), журналы стека. Сторонний action — только `actions/checkout@v5`. Секретов нет: пароли стенда генерируются в прогоне |
| `docs/admin-guide.md` | Установка за ≤ 30 мин, переменные, секреты, HTTPS и `SESSION_COOKIE_SECURE`, сессия 12 ч, режимы и локальный акт перед `enforce`, правила денег, импорт и ключи, раздел «Импорт через корпоративный прокси», раздел «Webhook» (формат тела, повторы, статусы, IP вместо имени), резервные копии, закрытый контур, чек-лист «Проверка поставки на своём стенде» (§14), неполадки |

### Команды готовности и вывод

**T087, статика (3Д1(а)) — PASS**
```
$ docker compose -f deploy/docker-compose.yml --env-file deploy/.env.example config --quiet   → exit 0
$ docker compose -f deploy/docker-compose.test.yml config --quiet                             → exit 0
$ make compose-check
tests/deploy/test_compose_static.py::test_core_network_is_internal PASSED
tests/deploy/test_compose_static.py::test_db_and_backup_only_in_core[postgres|backup] PASSED
tests/deploy/test_compose_static.py::test_api_port_from_bind_addr_and_api_port PASSED
tests/deploy/test_compose_static.py::test_healthcheck_and_restart[api|backup|postgres|worker] PASSED
tests/deploy/test_compose_static.py::test_secret_values_never_in_rendered_config PASSED
tests/deploy/test_compose_static.py::test_prometheus_multiproc_dir_on_tmpfs_only_at_api PASSED
tests/deploy/test_compose_static.py::test_import_https_proxy_passed_to_worker PASSED
... ============================== 48 passed in 0.85s ==============================   EXIT 0
```
Отрицательные проверки (мутации compose-файла, по одной):
```
internal: true → false                       1 failed, 36 passed
tmpfs каталога метрик убран                  1 failed, 36 passed
IMPORT_HTTPS_PROXY у worker убран            1 failed, 36 passed
restart: unless-stopped → always             4 failed, 33 passed
postgres/backup добавлены в edge             2 failed, 35 passed
DATABASE_URL тестовой БД в окружении         test_database_url_has_no_password FAILED → найден дефект (compose
                                             берёт окружение раньше --env-file); исправлено в Makefile и тесте
```

**T087, стек из локальных процессов (3Д1(в)) — PASS-замена**
```
$ make up-local && make smoke BM_STACK=local && make backup BM_STACK=local && make restore BM_STACK=local && make smoke BM_STACK=local
stack.sh: postgres: 127.0.0.1:55432 (pid 14265)
stack.sh: готов: http://127.0.0.1:18080/readyz
========================= 4 passed, 6 skipped in 1.06s =========================
2026-10-21T05:37:37Z backup: OK .../deploy/local/.state/backups/bm-20261021T053737Z.dump (74432 байт)
2026-10-21T05:37:41Z restore: БД bm пересоздана (чистая)
2026-10-21T05:37:41Z restore: OK: восстановлено в bm, таблиц в public: 29
stack.sh: готов: http://127.0.0.1:18080/readyz
========================= 4 passed, 6 skipped in 1.05s =========================
CHAIN_EXIT=0
```
6 skipped — проверки `compose_only` (SPA из образа, healthy, uid ×2, каталог метрик, порт postgres), причина печатается в отчёте pytest.
Восстановление действительно возвращает состояние копии: после копии у 3 моделей `active=false` → после `make restore` `inactive=0`, `models=3`.
Сигналы (для драйвера T093):
```
api pgid 13316: 4 процессов → stack.sh kill api → 0 процессов; status: api stopped
stack.sh stop api       → 2,6 с, 0 процессов группы
stack.sh stop postgres  → 2,2 с; /readyz → {"status":"fail","db":"fail"}; start postgres → /readyz ok (api пережил перезапуск БД)
```
Чем замена отличается от compose: нет образа (SPA, uid 10001, HEALTHCHECK), нет сетей compose, PostgreSQL 16 вместо 18, процессы запущены от root (postgres — от пользователя postgres). Общий кластер 5432 не останавливался.

**T087, Docker — НЕ ПРОВЕРЕНО**
```
$ docker build --check -f deploy/Dockerfile .
ERROR: node:24-slim: failed to resolve source metadata ... registry-1.docker.io ...: Forbidden
```
Что удалось проверить без реестра:
- `docker build --check` с базовыми образами, подменёнными локальной заглушкой (`--build-arg PYTHON_IMAGE=… NODE_IMAGE=…`): `Check complete, no warnings found.` — синтаксис и линт Dockerfile в порядке, сборка не выполнялась;
- образ-заглушка (`docker import` из bash и libc хоста) и compose-файл с теми же конструкциями:
```
uid=10001 gid=10001
drwx------ 2 10001 10001 /run/bm-metrics           ← tmpfs с uid/gid работает
-r--r--r-- 1 0 0 6 s   S=[abc123]                  ← secrets.environment берёт значение из --env-file, файл 0444
E=[cat: /run/secrets/e: No such file or directory]  ← пустая переменная → файл не создаётся (обработано в entrypoint)
tmpfs-writable
```
- entrypoint на хосте: `*_FILE` без файла снимаются, `PGPASSWORD` выставлен, каталог метрик очищен; `healthcheck.py` (`_db_ok`) с `POSTGRES_PASSWORD_FILE` → `True`.

**T088 — `CHECK_STRICT=1 make check` на текущем дереве (с npm-веткой по `app/frontend`)**
```
=== Python: лицензии ===
deploy/ci/out/sbom-python.cdx.json: компонентов 28, нарушений 0
Исключения (deploy/ci/licenses-exceptions.txt): pypi:certifi@2026.10.19, unknown:budget-client@0.1.0
=== Python: уязвимости (pip-audit) ===
No known vulnerabilities found / pip-audit: пакетов 27, уязвимостей 0
deploy/ci/out/sbom-npm.cdx.json: компонентов 138, нарушений 0
npm SBOM: @tanstack/react-query@5.104.2 — MIT
7 moderate severity vulnerabilities  (decode-uri-component ← query-string ← ra-core; порог — critical)
=== Итог make check ===
OK    python: uv sync --frozen (lock-файл согласован)
OK    python: budget_client в окружении поставки (для SBOM)
OK    python: SBOM deploy/ci/out/sbom-python.cdx.json
OK    python: лицензии по белому списку
OK    python: pip-audit — известных уязвимостей нет
OK    python: import-linter
OK    npm: нет @react-admin/ra-*
OK    npm: SBOM deploy/ci/out/sbom-npm.cdx.json
OK    npm: лицензии по белому списку
OK    npm: audit — критичных уязвимостей нет
FAIL  trivy: не установлен (в CI — контейнер Trivy, T092) (пропуск запрещён: CHECK_STRICT=1)
make check: FAIL                                                     STRICT_EXIT=2
$ make check   →  SKIP trivy … / make check: OK (SBOM и отчёты — deploy/ci/out/)   EXIT 0
```
В строгом режиме единственный FAIL — Trivy: здесь он НЕ ПРОВЕРЕНО, по 3Т это допускается. SBOM лежат в `deploy/ci/out/`. В SBOM есть `budget-client`, `mcp*` нет (0 совпадений). Ветка Trivy проверена заглушкой команды (`TRIVY=<скрипт>`, `IMAGE=<образ-заглушка>`): при 0 critical — `OK … make check: OK`, exit 0; при critical — `FAIL trivy: есть critical`, exit 1. Сам Trivy при этом не запускался.
Проверки лицензий (`tests/deploy/test_check_licenses.py`, 11 passed): MIT-0 разрешён; MPL-2.0 без исключения — FAIL; исключение `certifi@<версия из uv.lock>` действует только на эту версию; запись без версии — exit 2; GPL/AGPL/LGPL/SSPL — FAIL даже при записи в исключениях (мутация «исключение без проверки копилефта» → 4 failed); `@react-admin/ra-*` — ENTERPRISE.

**T092 — синтаксис workflow (actionlint есть: `actionlint-py` 1.7.12 с PyPI, вместе с shellcheck 0.11.0)**
```
$ actionlint -verbose .github/workflows/ci.yml
verbose: Found 0 parse errors in 0 ms for .github/workflows/ci.yml
verbose: Found total 0 errors in 329 ms for .github/workflows/ci.yml        rc=0
$ actionlint ci-bad.yml   (runs-on → runs_on, незакрытая кавычка в run:)
… "runs-on" section is missing in job "test" [syntax-check]
… shellcheck reported issue in this script: SC1072:error … [shellcheck]
$ shellcheck -S warning deploy/local/stack.sh deploy/backup/*.sh deploy/docker-entrypoint.sh deploy/ci/*.sh deploy/run-tests.sh   rc=0
```
Прогона CI нет: репозиторий из сессии недоступен (API GitHub — 403). Журнала нет, поэтому все пункты CI — **НЕ ПРОВЕРЕНО**.

**Полный `make test` и `make lint`**
```
$ DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test_devops make test
БД доступна: PostgreSQL 16.15 …
================== 721 passed, 1 xfailed in 213.75s (0:03:33) ==================
Contracts: 3 kept, 0 broken.
 Test Files  28 passed (28)
      Tests  363 passed (363)
run-tests.sh full: OK                                                EXIT=0
$ make lint   → Contracts: 3 kept, 0 broken. / All checks passed! / 161 files already formatted   EXIT 0
```
1 xfail — `test_6_2_csv_injection_is_neutralized` (QA, 3Б5, T093). Прогон шёл на отдельной БД `bm_test_devops`, которую я создал на общем кластере (сам кластер не останавливался), чтобы не мешать параллельным прогонам на `bm_test`. Первый прогон завис на `test_us4_subscriptions` во время перезапуска общего кластера и был снят. Повтор — зелёный.

### Отклонения

1. **certifi поднят до 2026.10.19 (транзитивная зависимость, только `uv.lock`).** `pip-audit` нашёл в 2026.7.22 уязвимость PYSEC-2026-4320 / GHSA-6q48-6c7w-9gw2 (скомпрометированные промежуточные CA emSign, возможен MITM). Под удар попадает TLS импорта к провайдерам. Без обновления `make check` падает. Лицензия та же, MPL-2.0. Узкое исключение (3Д3) перенесено на новую версию. **Нужно подтверждение техлида** (вопрос 1).
2. **Артефакты CI без `actions/upload-artifact`.** По 3Д4 разрешён только checkout. Сводка `make check` и SBOM (gzip+base64, с sha256) печатаются в журнал прогона, а SBOM восстанавливается из журнала. Если техлид разрешит официальный `actions/upload-artifact`, это одна строка (вопрос 3).
3. **Версии в CI не проверены** [Гипотеза]: `actions/checkout@v5`, `aquasec/trivy:0.58.0`, `node:24-slim`. Реестры и API GitHub закрыты. Digest базовых образов печатает шаг CI, после первого прогона их нужно закрепить в Dockerfile.
4. **`make smoke` при первом входе меняет временный пароль** на `BM_ADMIN_PASSWORD`. Без этого ключевой сценарий smoke на чистой установке не пройти: API требует смены пароля. Это описано в admin-guide и в `.env.example`.
5. **Контейнер `backup` работает от root.** Том `/backups` создаётся с владельцем root. Контейнер только в `core` (internal), портов нет. Переход на `gosu postgres` — после проверки в CI.
6. **`IMPORT_HTTPS_PROXY` передаётся через окружение `worker`**, а логин и пароль прокси в URL видны в `docker inspect`. Варианта `*_FILE` для этой переменной в `Settings` нет (вопрос 4).

### Нужны правки в коде (не моя зона)

1. **Backend: раздача SPA.** Образ кладёт `dist` в `/app/static/admin`, но `bm.main` статику не отдаёт: `GET /admin/` на локальном стеке → **404** (проверено). `compose_only`-тест `test_admin_spa_served_from_image` в CI упадёт, и это правильно: гейт не должен быть зелёным без админки. Предложение: `StaticFiles(directory="/app/static/admin", html=True)` на `/admin`, если каталог есть. Путь можно вынести в константу или переменную; в compose это всегда `/app/static/admin`.
2. **Backend (T062): `IMPORT_HTTPS_PROXY`** в `Settings` и `bm.egress` пока не реализован: переменная есть только в списке маскирования журналов. Поставка её уже передаёт `worker`.

### Вопросы техлиду

1. Подтвердить обновление certifi до 2026.10.19 и перенос узкого исключения на эту версию (отклонение 1).
2. T087 и T092 остаются `[ ]`, пока нет журнала CI. Кто и когда запускает CI на репозитории проекта (нужен push `.github/workflows/ci.yml` и раннер с доступом к Docker Hub)? До этого в `16_release.md` уходят как НЕ ПРОВЕРЕНО: сборка образа, стек в Docker, Trivy, `egress-host-check`, PG 18, SC-009.
3. Разрешить ли `actions/upload-artifact` для SBOM (отклонение 2)?
4. Нужен ли `IMPORT_HTTPS_PROXY_FILE` (backend, `Settings`), чтобы учётные данные прокси не лежали в окружении контейнера?
5. Можно заранее, до CI, проверить compose-стек целиком на образах, собранных из файлов хоста (`docker import`; так уже проверены secrets и tmpfs). Статус будет PASS-замена, не PASS, работы примерно на 0,5 дня. Делать?

---

## 2026-10-21 — пакет 4: разбор CI `eb17642`, аннотации, 4Д1, 4Д3, 4Д4, 4Д8, 4Д9 (T087, T092, T090)

Среда: Docker 29.8.2 / Compose 5.5.1, реестры 403 (образ локально не собрать). PostgreSQL 16.15, БД `bm_test_devops`.

### Итог

| ID | Отметка | Что изменилось |
|---|---|---|
| T092 | `[ ]` | CI диагностируется через аннотации: `deploy/ci/gha.py` (`::error` с хвостом вывода или сводкой pytest, `::notice` со сводкой гейтов и digest), гейты разнесены по отдельным шагам, `upload-artifact`, base64-дамп SBOM убран. `actionlint` — 0 ошибок. Закрытие — по аннотациям/журналу релизного SHA |
| T087 | `[ ]` | `IMPORT_HTTPS_PROXY` — compose secret только у `worker` (4Д4); `start_interval: 2s` у healthcheck, `--wait-timeout 180`; `BM_COMPOSE` без `DATABASE_URL` для smoke/failover. Digest базовых образов — не закреплён [Гипотеза], CI печатает его в `::notice` |
| T090 | `[ ]` | Правки 4Д9 (1)–(6) в `docs/admin-guide.md`. Чистая машина — НЕ ПРОВЕРЕНО (4Д9) |

`make test` (БД `bm_test_devops`): **766 passed; import-linter 3 kept; frontend 28 файлов / 363 теста passed; `run-tests.sh full: OK`, EXIT=0.**

### Разбор прогона 39552101693 (`eb17642`) — статусы гейтов (репетиция, в релиз как PASS не идут, 4Д1)

| Гейт | Статус на `eb17642` | Основание |
|---|---|---|
| `make lint`, `make compose-check`, `make test` на PostgreSQL 18, frontend (Node 24) | PASS (репетиция) | [Факт] задача `test` — SUCCESS |
| `actions/checkout@v5` | разрешается | [Факт] задача `test` прошла checkout; пометка [Гипотеза] снята |
| `make build` (образ из настоящих базовых образов), шаг digest | PASS (репетиция) | [Вывод] шаги идут по порядку, упал следующий за ними шаг |
| `make up && make smoke && make backup && make restore && make smoke` | **FAIL**, подшаг неизвестен | [Факт] exit 2 — так `make` сообщает об ошибке любого рецепта, поэтому код не различает подшаги. Аннотация «.github, строка 152» — [Вывод] стандартная аннотация раннера «Process completed with exit code 2», на подшаг не указывает |
| `make failover`, `CHECK_STRICT=1 make check` (Trivy), `egress-host-check` | НЕ ПРОВЕРЕНО | [Факт] skipped |

**Вероятная причина падения (статически):**
1. **[Вывод, основная] Первый `make smoke` падает на `test_admin_spa_served_from_image`**: `GET /admin/` → 404, в `bm.main` на `eb17642` нет `StaticFiles` (4Д6). В текущем дереве монтирования тоже ещё нет (T096 у Backend 2 в работе). Это ожидаемое падение, его снимает T096, а не CI: тест не ослабляю.
2. [Гипотеза] `make up --wait --wait-timeout 120` впритык: первые проверки healthcheck шли через `interval` (у `worker` 30 с, у `backup` 60 с) после старта, а `worker` стартует только после healthy `api`. Оценка — около 70 с при 120 с лимита. Исправлено: `start_interval: 2s` у всех четырёх сервисов (нужен Docker Engine ≥ 25 [Гипотеза]: версию раннера теперь печатает `::notice`), `--wait-timeout 180` в `up` и `restore`.
3. [Гипотеза] Пустые секреты (`ANTHROPIC_ADMIN_KEY` и др.): то, что compose не создаёт файл для пустой переменной, проверено только на Compose 5.5.1. Entrypoint обрабатывает и отсутствующий, и пустой файл (`-s`); если версия на раннере ведёт себя иначе, это покажет аннотация «состояние стека».
4. [Вывод, мелочь] smoke и failover вызывали `docker compose` с тестовым `DATABASE_URL` из окружения `make`. Для `ps/exec/stop/start` это безвредно, но при пересоздании контейнера подменило бы БД стека. Теперь Makefile экспортирует `BM_COMPOSE=$(COMPOSE_MAIN)` (с `env -u DATABASE_URL`).

Код приложения не менялся.

### Что сделано (файлы)

| Файл | Что |
|---|---|
| `deploy/ci/gha.py` (новый, stdlib) | `run --title T [--stack] -- cmd`: вывод в журнал и в `deploy/ci/out/gha/<шаг>.log`; код выхода — как у команды; при падении — `::error title=T (exit N)::<хвост>`. Если в выводе есть сводка pytest (`short test summary info`), в аннотацию идёт она, а не хвост. Перевод строки экранируется как `%0A`, а также `%`, `\r`; в title ещё `:` и `,`. ≤ 4000 байт UTF-8 без разрыва символа. `--stack` — вторая аннотация «состояние стека»: `compose ps -a` и `logs --tail 40` сервисов не в состоянии running/healthy. Бюджет — ≤ 10 аннотаций на задачу, 2 из них оставлены под notice (счётчик в файле). Маскирование: значения `POSTGRES_PASSWORD`, `SESSION_SECRET`, `ADMIN_INITIAL_PASSWORD`, `BM_ADMIN_PASSWORD`, ключей и прокси из `deploy/.env` и окружения печатаются как `::add-mask::` до первой аннотации и заменяются на `***`; пароль в URL (`://u:p@`) тоже. `notice` — stdin → `::notice`. `summary` — гейты (`gates.tsv`), исходы шагов (`STEPS_JSON = toJSON(steps)`), sha256 SBOM, не-OK строки `summary.txt` make check → одна `::notice` |
| `tests/deploy/test_ci_annotations.py` (новый, 12 тестов) | Красная фаза: модуля не было. Проверяется: проход без аннотаций; падение → один `::error` с экранированием и тем же кодом; экранирование title; обрезка до 4 КБ UTF-8; приоритет сводки pytest; маскирование (из файла, окружения, URL) и порядок `add-mask` → `error`; бюджет 10 (11-я не печатается); аннотация состояния стека (логи только нездоровых сервисов); сводка с шагами, sha256 и FAIL из `summary.txt`; ошибки использования → exit 2 |
| `.github/workflows/ci.yml` | Каждый гейт — отдельный шаг через `gha.py run`: `make lint`, `compose-check`, `test`, frontend; `build`, `up`, `smoke`, `backup`, `restore`, `smoke после restore`, `failover`, `check`, `egress` (попытка). Зависимые шаги — через `if: !cancelled() && steps.<id>.outcome == 'success'`: smoke/backup/failover/egress — после `up`, restore — после backup, check — после build. Поэтому один прогон показывает статус каждого гейта, а задача остаётся красной. Пароли стенда генерируются в переменные, маскируются `::add-mask::` до записи в `deploy/.env` (раньше маскировался только `BM_ADMIN_PASSWORD`). Шаг «Версии и digest базовых образов» (`python:3.13-slim`, `node:24-slim`, `postgres:18`, `aquasec/trivy:0.58.0`, версии docker и compose) → `::notice`. В задаче `test` — `::notice` с версиями (uv, docker, compose, `SHOW server_version` PostgreSQL). В конце каждой задачи — сводка `::notice`. `actions/upload-artifact@v4` [Гипотеза: версия не проверена, API GitHub из сессии — 403]: `delivery-<sha>` (`deploy/ci/out/` — SBOM, `summary.txt`, журналы гейтов; `compose-logs.txt`), `test-<sha>` (журналы гейтов). Base64-дамп SBOM убран, sha256 SBOM и `summary.txt` остаются в журнале (4Д3) |
| `deploy/docker-compose.yml` | 4Д4: секрет `import_https_proxy` (источник — `IMPORT_HTTPS_PROXY`) только у `worker`, `IMPORT_HTTPS_PROXY_FILE=/run/secrets/import_https_proxy`, переменной `IMPORT_HTTPS_PROXY` в окружении больше нет. `start_interval: 2s` у healthcheck всех сервисов |
| `deploy/docker-entrypoint.sh` | `IMPORT_HTTPS_PROXY_FILE` снимается, если файла нет или он пуст (прямой выход), как у ключей провайдеров |
| `deploy/.env.example` | `IMPORT_HTTPS_PROXY` — в списке секретов, комментарий: передаётся только `worker` файлом через `IMPORT_HTTPS_PROXY_FILE`. Комментарий к `WEBHOOK_URL` — без «имя проверяется только при старте», добавлено «127/8 — это сам контейнер worker» |
| `tests/deploy/test_compose_static.py` | Прокси добавлен в секреты-метки: значения нет в отрендеренной конфигурации, источник секрета — переменная окружения. Новый `test_import_https_proxy_passed_to_worker_as_secret_file`: у `worker` есть `_FILE`, нет `IMPORT_HTTPS_PROXY`, в окружении нет `proxy-pass`; у `api`, `postgres` и `backup` нет ни переменной, ни секрета. Новый `test_entrypoint_drops_proxy_file_when_secret_is_empty`. Шаблон упоминает `IMPORT_HTTPS_PROXY_FILE`. Красная фаза: 6 failed, 32 passed → после правок 61 passed (весь `tests/deploy`) |
| `Makefile` | `BM_COMPOSE ?= $(COMPOSE_MAIN)` (экспорт), `--wait-timeout 180` в `up` и `restore`, `pytest tests/failover -v -ra` (сводка причин для аннотации) |
| `deploy/Dockerfile` | Комментарий: digest не закреплён [Гипотеза] — реестры 403, журнал `eb17642` недоступен, digest придёт в `::notice`. Теги не менялись |
| `docs/admin-guide.md` (4Д9) | (1) §9: абзац про незакрытую T062 удалён. (2) §10: «Webhook входит в v1», оговорка про 🔻2 убрана. (3) §10: адрес проверяет `bm.egress` в начале каждого такта, отказ — `job_run.error_class=EgressForbidden`, уведомления остаются `pending`; DNS rebinding между проверкой и соединением не контролируется. [Факт по коду] `deliver_pending` создаёт клиент `get_client("webhook")` в каждом такте, `_resolve` — `getaddrinfo`. Бюджет 30 с за такт — [Факт по коду] `TICK_BUDGET_S = 30.0` в `bm/notify/channels.py` (T096, Backend 2). (4) §10: `127.0.0.0/8` — это сам `worker`. (5) §14: пункт 10 «Единицы сумм импорта» (4Б1) и примечание, что CI его не проверяет. (6) §4 и §9: `IMPORT_HTTPS_PROXY` — файл-секрет, только у `worker`. Плюс в §14: аннотации CI заменяют журнал |

### Команды готовности и вывод

```
$ uv run … pytest tests/deploy/test_ci_annotations.py          (до gha.py: модуля нет → все падают)
12 passed in 3.31s
$ uv run … pytest tests/deploy/test_compose_static.py          (красная фаза 4Д4)
6 failed, 32 passed      → после правок compose/entrypoint/.env.example:
$ uv run … pytest tests/deploy -q
61 passed in 5.96s
$ actionlint -verbose .github/workflows/ci.yml                  (actionlint-py + shellcheck-py)
verbose: Found 0 parse errors … / Found total 0 errors          rc=0
$ shellcheck -S warning deploy/docker-entrypoint.sh             rc=0
$ python3 deploy/ci/gha.py run --stack --title "make up" -- sh -c 'echo нет образа; exit 2'   (без стека)
::error title=make up (exit 2)::нет образа
::error title=make up%3A состояние стека::couldn't find env file: …/deploy/.env%0A--- logs (api, worker) ---%0A…
$ STEPS_JSON='{"up":{"outcome":"failure"}}' python3 deploy/ci/gha.py summary
::notice title=Сводка CI::Гейты:%0A  make compose-check: PASS (5 с)%0A  make up: FAIL (exit 2, 0 с)%0AШаги: up: failure%0Asbom-npm.cdx.json sha256=3ba7…%0A…
$ DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test_devops make test
======================= 766 passed in 305.19s (0:05:05) ========================
Contracts: 3 kept, 0 broken.
 Test Files  28 passed (28)
      Tests  363 passed (363)
run-tests.sh full: OK                                            EXIT=0
$ make lint
E501 app/backend/bm/main.py:53, app/backend/bm/notify/channels.py:10, :12   → Error 1   (не моя зона, см. ниже)
```
Мои файлы (`deploy/`, `tests/deploy/`) — `ruff check` и `ruff format --check` чистые.

### Отклонения

1. **Digest базовых образов не закреплён (4Д1 (2)).** Реестры 403, журнал недоступен. Теги остались, пометка [Гипотеза] — в Dockerfile. Digest будет в аннотации `::notice` «Версии и digest базовых образов» следующего прогона; перенос в `ARG …=python:3.13-slim@sha256:…` — одна правка после прогона.
2. **Цепочка `up && smoke && backup && restore && smoke` разнесена по шагам**, и после упавшего smoke шаги backup/restore/failover/check всё равно выполняются. Порядок команд прежний, а задача остаётся красной при любом FAIL. Зачем: на `eb17642` одно ожидаемое падение (4Д6) скрыло статусы остальных гейтов.
3. **Связка с T097.** В начале моей работы в `_FILE_SECRETS` не было `import_https_proxy`, а `IMPORT_HTTPS_PROXY_FILE` попадал бы в `extra="ignore"`. К концу работы Backend 1 добавил его в рабочее дерево [Факт: `bm/settings.py`, строка `"import_https_proxy",  # T097`]. Compose-правка 4Д4 работает только вместе с T097 — выпускать на одном SHA.
4. **`start_interval` требует Docker Engine ≥ 25** [Гипотеза]. Если на раннере движок старше и compose отклонит ключ, это покажет аннотация `make up` (exit 1, текст ошибки compose). Тогда ключ убирается.
5. 4Д8: (4) смена пароля в smoke и (5) `backup` от root — приняты как есть, без изменений.

### Нужны правки в коде (не моя зона)

1. **Backend 2 (T096):** на момент моего `make lint` он красный, E501 (> 110 символов): `bm/main.py:53`, `bm/notify/channels.py:10` и `:12`. Это файлы T096 в работе. Если так и уйдёт в push, в CI упадёт шаг `make lint`.
2. **Backend 2 (T096):** к концу моей работы в рабочем дереве появилось монтирование `/admin` (`StaticFiles`, `bm/main.py`). Мой `make test` шёл параллельно с их правками, поэтому какая версия `main.py` в нём проверена, не гарантирую. Без T096 smoke в CI останется FAIL.
3. **Backend 1 (T097):** см. отклонение 3.

### Что проверить в следующем прогоне CI (по аннотациям)

- `::notice` «Сводка CI test» / «Сводка CI delivery»: PASS/FAIL каждого гейта и исходы шагов;
- `::error title=make smoke (exit 2)`: должна остаться только строка `FAILED …test_admin_spa_served_from_image` (если T096 не вошёл) или аннотации нет;
- `::error … состояние стека`: все 4 сервиса `running healthy`, иначе — журнал сервиса;
- `make backup`, `make restore`, `make smoke после restore`, `make failover`, `CHECK_STRICT=1 make check` (Trivy 0 critical, тег `aquasec/trivy:0.58.0` разрешается), попытка `egress-host-check`: у каждого есть статус;
- `::notice` «Версии и digest базовых образов» → закрепить digest в Dockerfile; версия Docker Engine ≥ 25 (для `start_interval`);
- `::notice` «Версии (test)»: `postgres 18.x`;
- в аннотациях нет значений паролей (только `***`); `actions/upload-artifact@v4` разрешился (артефакты `test-<sha>`, `delivery-<sha>` есть в API).

### Вопросы техлиду

1. T096 и T097 — выпускать вместе с этими правками на релизном SHA? Иначе smoke останется FAIL (4Д6), а прокси из файла не прочитается (отклонение 3).
2. Устраивает ли разнесение цепочки по шагам (отклонение 2) как форма гейта «`make up && make smoke && make backup && make restore && make smoke`»? Порядок и команды прежние.

## 2026-10-21 — пакет 5: T099 (Trivy CRITICAL certifi), часть DevOps в T098, 5Д5, 5Д7, 5Д8 (1)

**Итог.** Источник `certifi` 2026.6.17 — `pip` базового образа `python:3.13-slim` (вложенный `pip/_vendor/certifi`), который стадия `python-runtime` наследовала целиком [Вывод, подтверждение — notice CI]. `pip` из рантайма удалён; сборка падает, если `pip` или пакет `certifi` остались вне `/app/.venv`. Digest базовых образов закреплены по аннотации прогона `899cf1e`. В CI — `::notice` с путём каждой установки `certifi` (Target/FilePath) в `bm:local` и в базовом образе при любом исходе `make check`. npm: гейт только critical, 7 moderate — `WARN` с перечнем advisory. `CMD` и `stack.sh` — `python -m bm.serve`. Цель `load` — в зоне DevOps. `make test` (bm_test_devops) — exit 0, `make lint` — 0, `actionlint` (с shellcheck) — 0. T099 — `[x]` по исправлению источника; окончательно — по CI релизного SHA.

Контекст: правки прерванной попытки на CI `899cf1e` не попали (не были закоммичены) — там `CHECK_STRICT=1 make check` упал на той же находке, остальная поставка PASS (со слов оркестратора).

### T099: источник certifi 2026.6.17

| Что | Результат |
|---|---|
| `/app/.venv` | `uv.lock`: `certifi` 2026.10.19, в коммите `34d28d0` — тоже 2026.10.19 (`git show 34d28d0:app/backend/uv.lock`) [Факт]. Окружение собирается `uv sync --frozen`, `pip` в него не ставится (uv-venv без seed) [Вывод] |
| Стадия `python-runtime` | `FROM ${PYTHON_IMAGE}` — наследует весь `site-packages` базового образа, в том числе `pip` и `ensurepip/_bundled/pip-*.whl`; `python-base` (где `pip install uv`) в рантайм не попадает [Факт по Dockerfile] |
| Вложенный certifi у pip | `pip/_vendor/vendor.txt`: pip 26.2 и 26.2.1 — `certifi==2026.6.17`; pip 26.2.2 (wheel от 2026-10-20) — `certifi==2026.10.19` [Факт: `pip download pip==…`, `unzip -p … pip/_vendor/vendor.txt`] |
| Какой pip в Python 3.13 | Локальный CPython 3.13.16: `ensurepip.version()` = 26.2.1 [Факт]. Что образ по digest `cf50a4f6…` несёт pip 26.2.x с certifi 2026.6.17 — [Гипотеза], подтверждается notice CI по базовому образу |
| Вывод | Совпадение версии 1:1 и отсутствие других кандидатов: источник — `/usr/local/lib/python3.13/site-packages/pip/_vendor/certifi` (и копия в wheel ensurepip) [Вывод]. Обновление digest само по себе не годится: нужен образ с pip ≥ 26.2.2 (wheel вышел 2026-10-20), а наличие такого образа не проверено (реестры закрыты); на 899cf1e (тег python уже сдвинулся на `cf50a4f6…`) Trivy снова нашёл 2026.6.17 [Факт по аннотации со слов оркестратора] |

Вывод команд (сокращённо):
```
$ pip download --no-deps pip==26.2 / 26.2.1 / 26.2.2; unzip -p <whl> pip/_vendor/vendor.txt | grep certifi
pip-26.2-py3-none-any.whl:     certifi==2026.6.17
pip-26.2.1-py3-none-any.whl:   certifi==2026.6.17
pip-26.2.2-py3-none-any.whl:   certifi==2026.10.19
$ python3 -V; python3 -c "import ensurepip; print(ensurepip.version())"
Python 3.13.16
26.2.1
# проверка механики удаления на venv с pip 26.2.1 (как в образе):
$ find v \( -name certifi -o -name 'certifi-*' \)      → .../pip/_vendor/certifi, .../pip-26.2.1.dist-info/licenses/src/pip/_vendor/certifi
$ v/bin/python -m pip uninstall --yes pip             → Successfully uninstalled pip-26.2.1
$ v/bin/python -c 'import pip'                        → ImportError (PIP_GONE); find → пусто
```

**Исправление (`deploy/Dockerfile`, стадия `python-runtime`, до `COPY /app/.venv`):** `python -m pip uninstall --yes pip`; удаление `/usr/local/lib/python3.*/ensurepip/_bundled` и `/usr/local/bin/pip*`; сборка падает, если `import pip` удаётся или `find / -xdev \( -name certifi -o -name 'certifi-*' \)` что-то находит (маска не `*certifi*` — совпала бы с `ca-certificates`). Рантайму `pip` не нужен: зависимости — готовый `.venv`, healthcheck и entrypoint — только `python`/`sh`. `.trivyignore`, `--ignore-unfixed`, понижения порога нет — закреплено тестом.

**Диагностика источника в CI (`::notice`).**
- `deploy/ci/check.sh`: `trivy image --format json --list-all-pkgs --severity CRITICAL` → `deploy/ci/out/trivy-critical.json` **при любом исходе** (до гейта; на гейт не влияет). Гейт — прежняя единственная строка `--severity CRITICAL --exit-code 1`.
- `ci.yml`, шаг «Trivy — путь certifi в образе и в базовом образе (::notice)» (`if: build success`, `continue-on-error`): тот же JSON по базовому образу из `ARG PYTHON_IMAGE` Dockerfile (по digest) → `trivy-base.json`, затем `gha.py trivy --pkg certifi --json trivy-critical.json --json trivy-base.json`.
- `gha.py trivy` → одна `::notice` «Trivy: CRITICAL и путь certifi»: по каждому отчёту — `CRITICAL N`; для каждой CRITICAL — `Target/Class/Type`, ID, версия → исправленная, `PkgPath`, `FilePath`; все установки `certifi` (версия, Target, FilePath) или «certifi: не найден»; нет/битый отчёт — строкой в той же notice. Код выхода 0. Бюджет аннотаций delivery: +1 notice (лимит 10).

**Digest (аннотация прогона `899cf1e`; на `34d28d0` python и node были `98ce6fb1…` и `91acba91…` — теги сдвинулись):**
| Образ | Где закреплён |
|---|---|
| `python:3.13-slim@sha256:cf50a4f6ac4f026458b08d5222023d700ac806410dff5e9ca8728fa44f2b850f` | `deploy/Dockerfile` `ARG PYTHON_IMAGE` |
| `node:24-slim@sha256:55fb5f5a527ea2c5c4a95f963e48ef90aa38c7b346054fdc8ee9957a2b55d205` | `deploy/Dockerfile` `ARG NODE_IMAGE`, `ci.yml` `NODE_IMAGE` |
| `postgres:18@sha256:1267c7e692de235fda2a50dbcdbcbca4672ea6a0298576a6bd9d07cafc319b32` | `ci.yml` (service задания test), `deploy/docker-compose.test.yml` |
| `aquasec/trivy:0.58.0@sha256:b88012e2a0a309d6a8a00463d4e63e5e513377fb74eccbc8f9b0f8f81940ebeb` | `ci.yml` `TRIVY_IMAGE` |

Шаг `digests` печатает digest **тегов** — дрейф тега относительно закреплённого digest виден в аннотации.

### 5Д5: npm audit — гейт только critical, moderate — WARN с перечнем advisory

`check.sh`: гейт — `npm audit --omit=dev --audit-level=critical` (как было); затем `npm audit --omit=dev --json` → `deploy/ci/out/npm-audit.json` → `deploy/ci/npm_advisories.py` → `deploy/ci/out/npm-advisories.txt`, в итог — строка `WARN` (новая функция `warn()`, `FAILED` не трогает). `WARN` попадает и в `::notice` «Сводка CI» (там все строки, кроме `OK`).

Advisory для `16_release.md` («Известные ограничения»; `npm audit --json --omit=dev`, 2026-10-21) [Факт]:
| Advisory | Пакет | Уязвимый диапазон | Суть |
|---|---|---|---|
| GHSA-vcc3-ghjq-m6fr (npm 1147955), moderate | `decode-uri-component` | `<=0.4.2` | DoS через экспоненциальное декодирование некорректного percent-encoded ввода |

Транзитивно (та же advisory): `query-string`, `ra-core`, `ra-i18n-polyglot`, `ra-language-english`, `ra-ui-materialui`, `react-admin`. `fixAvailable` — только ломающее изменение (`isSemVerMajor: true`).

```
$ make check        (локально, без CHECK_STRICT; Trivy здесь не установлен)
OK    npm: audit — критичных уязвимостей нет
WARN  npm: audit — 7 moderate; advisory: GHSA-vcc3-ghjq-m6fr (moderate, decode-uri-component <=0.4.2) (не critical, 5Д5)
SKIP  trivy: не установлен (в CI — контейнер Trivy, T092)
make check: OK          rc=0
```

### T098 (часть DevOps)

- `deploy/Dockerfile`: `CMD ["python", "-m", "bm.serve", "--host", "0.0.0.0", "--port", "8080"]`; `ENV UVICORN_WORKERS=2` остаётся (читает `bm.serve`), `--no-server-header` → `server_header=False` в `bm.serve`. Entrypoint и healthcheck не меняются.
- `deploy/local/stack.sh`: `spawn api "$VENV/bin/python" -m bm.serve --host 127.0.0.1 --port "$API_PORT"`.
- `docs/admin-guide.md` команды uvicorn не содержит, строка `UVICORN_WORKERS` (по умолчанию 2) верна — правка не нужна.
- Регресс-тест Backend 2 `tests/integration/test_keepalive_latency.py` в `make test` — PASS.

### 5Д7, 5Д8 (1)

- `gha.py summary`: шаги с `outcome == skipped` выводятся строкой «Пропущены (предусловие не выполнено): …» — не PASS (в `gates.tsv` их и не было: `gha.py run` не запускался).
- `Makefile`: цель `load` — в зоне DevOps (комментарий, строка в шапке), поведение прежнее: `$(STACK_ENV) bash tests/load/run_load.sh`; закреплено тестом.

### Тесты (TDD)

- `tests/deploy/test_image_supply.py` (14): pip удалён и остатки проверяются до `COPY .venv`; нет исключений Trivy; JSON Trivy пишется до гейта; шаг CI с notice по образу и базовому образу при любом исходе; digest `899cf1e`; npm-гейт только critical, `warn()` без `FAILED`; цель `load`; `CMD`/`stack.sh` — `bm.serve`, нигде `uvicorn … --workers`.
- `tests/deploy/test_ci_annotations.py`: `gha.py trivy` → notice (не error), несколько отчётов, `--pkg`, чистый образ, нет/битый отчёт; сводка с пропущенными шагами.
- `tests/deploy/test_npm_advisories.py` (2): перечень advisory и транзитивных пакетов, итоговая строка; чистый и битый отчёт.

```
# красная фаза (после правки тестов, до кода):
12 failed, 69 passed   (gha.py trivy/summary — 5, test_image_supply — 5, npm_advisories — 2)
# зелёная:
$ pytest tests/deploy                                                   → 81 passed
$ DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test_devops make test   → exit 0
  797 passed, 1 skipped (test_serve.py:64: AF_INET6 недоступен в среде) in 210.67s
  Contracts: 3 kept, 0 broken; vitest: Test Files 28 passed (28), Tests 363 passed (363)
$ make lint                                                             → exit 0 (172 files already formatted)
$ uvx --with shellcheck-py --with pyflakes --from actionlint-py actionlint -verbose .github/workflows/ci.yml
  Found total 0 errors                                                  → exit 0
```

### Отклонения

1. **Образ локально не собран** (Docker-демон недоступен из среды, реестры закрыты): удаление pip проверено статически и на venv с pip 26.2.1; защита — проверки в самом `RUN` (сборка в CI упадёт на `make build`, а не пропустит образ). Ветка Trivy в `check.sh` локально не исполнялась (нет trivy и образа) — проверена `bash -n` и статическим тестом.
2. **`postgres` в `deploy/docker-compose.yml` по digest не закреплён** (дефолт `POSTGRES_IMAGE=postgres:18`): путь закрытого контура в руководстве §13 — `docker save`/`load` по тегу. Закреплены CI и `docker-compose.test.yml`. Вопрос 1.
3. Шаг notice по базовому образу — `continue-on-error`: если Trivy не скачает базовый образ, в notice будет «нет отчёта», гейт не страдает.

### Что проверить в CI релизного SHA

- `make build` — PASS (если упал: «pip остался» или «certifi вне /app/.venv: <путь>» в `::error`).
- `CHECK_STRICT=1 make check` — exit 0; в «Сводке CI» единственная не-OK строка — `WARN  npm: audit — 7 moderate; advisory: GHSA-vcc3-ghjq-m6fr …`.
- notice «Trivy: CRITICAL и путь certifi»: `bm:local: CRITICAL 0`, `certifi 2026.10.19 Target=Python FilePath=app/.venv/…` (одна установка); по базовому образу — `certifi 2026.6.17 … FilePath=usr/local/lib/python3.13/site-packages/pip/…` или «certifi: не найден» (тогда источник подтверждается только исчезновением находки — разберу по факту).
- notice digest: теги совпадают с закреплёнными или видно смещение; `make test` на `postgres:18@sha256:1267…`, frontend на `node@sha256:55fb…` — PASS; smoke/failover с `python -m bm.serve` — PASS.

### Разбор CI `92b3414`: certifi 2026.6.17 с FilePath=- — источник SBOM pip, а не колесо

Данные (со слов оркестратора): `make build` PASS (проверки pip/certifi в `RUN` прошли), Trivy: `bm:local` CRITICAL 1 — certifi 2026.6.17, `Target=Python`, `FilePath=-`; в базовом `python:3.13-slim` то же; certifi 2026.10.19 — в `app/.venv`. npm — только `WARN`.

| Проверка | Результат |
|---|---|
| Гипотеза «вложенный .whl» | **Не подтверждается** [Факт по исходникам Trivy v0.58.0]: python-анализатор (`pkg/fanal/analyzer/language/python/packaging/packaging.go`) берёт только `*.dist-info/METADATA` и egg (`EGG-INFO/PKG-INFO`, `.egg-info`, `.egg`); wheel не распаковывает |
| Что ещё есть в pip | `pip-26.2.1-py3-none-any.whl` содержит `pip/_vendor/bom.cdx.json` (CycloneDX 1.4) с компонентом `certifi 2026.6.17 pkg:pypi/certifi@2026.6.17` [Факт: `unzip -p … pip/_vendor/bom.cdx.json`] |
| Как его видит Trivy | SBOM-анализатор (`pkg/fanal/analyzer/sbom/sbom.go`) читает любые `*.cdx.json`, `*.spdx`, `*.spdx.json`; FilePath пакетам ставит только для `opt/bitnami/` — отсюда `FilePath=-` [Факт по коду] |
| Почему удаление не помогло | `pkg/fanal/applier/docker.go` `ApplyLayers`: приложения кладутся по ключу `<FilePath>/type:…`, whiteout удаляет по пути файла. У SBOM-пакетов FilePath пуст → whiteout `pip/` из нашего слоя их не снимает, находка из слоя базового образа остаётся [Факт по коду; Вывод о применении к нашему образу] |
| Официальный образ | `docker-library/python` 3.13/slim-trixie: CPython собирается `--with-ensurepip`, pip в `site-packages` и в `ensurepip/_bundled` [Факт по Dockerfile образа] |

**Исправление (`deploy/Dockerfile`).** Новая стадия `python-slim-clean` (`FROM ${PYTHON_IMAGE}`): пользователь `bm`, удаление pip / `ensurepip/_bundled` / `pip*`, затем `RUN --mount=type=bind,source=deploy/image_guard.py,…` — guard. `python-runtime` — `FROM scratch` + `COPY --from=python-slim-clean / /`: слоёв базового образа в итоговом нет, удалённый SBOM Trivy не увидит. `PATH` задан явно (ENV базового образа после scratch не наследуется; кроме `PATH` там только `GPG_KEY`, `PYTHON_VERSION`, `PYTHON_SHA256` — рантайму не нужны). Исключений Trivy нет.

**Guard `deploy/image_guard.py`** (stdlib, в образ не попадает): падает на каталоге `certifi`/`certifi-*`, на SBOM-файлах (`*.cdx.json`, `*.spdx`, `*.spdx.json`) и на архивах `.whl/.zip/.egg/.pyz` с certifi внутри; перечень архивов печатает всегда. Проверен на реальном pip 26.2.1:
```
$ python3 -m venv gv; image_guard.py gv
  certifi: gv/…/pip-26.2.1.dist-info/licenses/src/pip/_vendor/certifi
  certifi: gv/…/pip/_vendor/certifi
  SBOM: gv/…/pip/_vendor/bom.cdx.json                         → FAIL
$ gv/bin/python -m pip uninstall --yes pip; image_guard.py gv   → архивы: 0, OK
$ image_guard.py /usr/lib/python3.13/ensurepip
  архив с certifi: …/_bundled/pip-26.2.1-py3-none-any.whl       → FAIL
```

**CI.** В шаге «Trivy — путь certifi…» добавлена `::notice` «Образ: архивы, SBOM, certifi»: число слоёв `bm:local` и `find / -xdev` по `*.whl`, `*.zip`, `*.egg`, `*.pyz`, `*.cdx.json`, `*.spdx*`, `certifi*` внутри образа.

**npm и exit 2.** Exit 2 — код `make` при любом падении рецепта; `check.sh` выходит с 1 только при `FAILED=1`, который ставят `fail()` и `skip()` в строгом режиме; `warn()` его не трогает (закреплено тестом). Локально `make check` с `WARN npm` → rc=0. Значит, на 92b3414 exit 2 дала только строка `FAIL trivy` [Вывод].

**Smoke после первого старта** (api не стартовал) — зона Backend 2, код не трогал. Замечу: `python-runtime` теперь собирается иначе (scratch + копия корня), поэтому при разборе следующего прогона сначала смотрю, не связан ли сбой с образом.

```
# красная фаза: 8 failed (guard 4, стадии 3, test_compose_static 1); зелёная:
$ pytest tests/deploy                                                   → 87 passed
$ DATABASE_URL=…/bm_test_devops make test   → exit 0: 805 passed, 1 skipped; Contracts 3 kept; vitest 363 passed
$ make lint → exit 0;  actionlint (shellcheck, pyflakes) .github/workflows/ci.yml → exit 0
```

### Вопросы техлиду

1. Закреплять ли `postgres:18` по digest и в `deploy/docker-compose.yml`? Тогда в руководстве §13 путь `docker save`/`load` меняется на `docker pull postgres:18@sha256:…` + `docker tag` и требует проверки на стенде. Предлагаю для v1 оставить тег в compose, digest — в CI и `docker-compose.test.yml`.
