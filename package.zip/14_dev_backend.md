# 14. Отчёт backend-разработчика

## 2026-10-14 — Phase 2: T015, T016, T017, T018, T019

### Итог

| Задача | Статус | Ключевые файлы |
|---|---|---|
| T015 Каркас приложения и контрактный тест | готово | `bm/settings.py`, `bm/main.py`, `bm/http/errors.py`, `bm/http/deps.py`, `bm/http/routers/system.py`, `bm/metrics.py`, `bm/db/pool.py`, `tests/contract/test_openapi_contract.py`, `tests/integration/test_system.py`, `tests/unit/test_settings.py` |
| T016 Вход, роли, аудит | готово | `bm/access/{auth,permissions,authorize,audit}.py`, `bm/http/routers/auth.py`, `bm/http/schemas.py`, `tests/unit/test_permissions.py`, `tests/acceptance/test_auth.py` |
| T017 Egress и «0 исходящих» | готово | `bm/egress/client.py`, `app/backend/importlinter.ini`, `tests/security/test_no_egress.py` (страж `socket.connect` в `tests/conftest.py` уже был) |
| T018 Снимок конфигурации | готово | `bm/budget/snapshot.py`, `bm/config/service.py`, `tests/integration/test_snapshot.py` |
| T019 Ядро уведомлений | готово | `bm/notify/{service,channels}.py`, `bm/http/routers/notifications.py`, `tests/integration/test_notify_once.py` |

Порядок работы: T015 → T016 → T019 → T017 → T018. По каждой задаче сначала писался тест и подтверждалось его падение (ImportError или отсутствие маршрута), затем код.

### Проверка (команды готовности)

```
$ DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test SKIP_FRONTEND=1 make test
БД доступна: PostgreSQL 16.x  (предупреждение: целевая версия — 18)
======================= 240 passed, 50 xfailed in 35.05s =======================
сетевые библиотеки (httpx, urllib, http, socket) — только в bm.egress KEPT (3 ignored imports)
bm.domain не зависит от ввода-вывода и других модулей bm KEPT
ядро не импортирует адаптеры (http, mcp, worker) KEPT
Contracts: 3 kept, 0 broken.
run-tests.sh full: OK                                   → exit 0

$ make lint
Contracts: 3 kept, 0 broken.
ruff check: All checks passed!
ruff format --check: 62 files already formatted         → exit 0
```

Было 136 тестов, стало 240 (+104). 50 xfailed — это операции контракта, роутеры которых появятся позже (`PENDING` в контрактном тесте, `xfail(strict=True)`).

Контракт import-linter проверен на нарушение: временный `import urllib.request` в `bm.access.audit` дал BROKEN с цепочками `bm.http → bm.access.audit → urllib` и `bm.main → …`. Импорт `bm.egress` из `bm.notify` проходит, как и задумано.

### Что сделано и как устроено

**T015.**
- `create_app(settings=None, clock=None)`: без аргументов настройки читаются из окружения. Это совместимо с `uvicorn bm.main:create_app --factory` в `deploy/Dockerfile`.
- Lifespan создаёт пул asyncpg, применяет миграции (под advisory-блокировкой из T014) и создаёт первого администратора.
- Swagger UI, ReDoc и `/openapi.json` выключены: UI грузит скрипты с CDN (принцип IV). Источник истины — `12_openapi.yaml`.
- Ошибки отдаются как `application/problem+json` с `detail` на русском:
  - 422 перечисляет только имена полей, тело запроса не повторяется (принцип I);
  - 500 отдаётся без подробностей;
  - 404 и 405 тоже идут в формате Problem.
- `/readyz` отвечает 503, если БД недоступна или не применена последняя миграция из образа.
- `/metrics` использует `text/plain; version=0.0.4` по контракту. В prometheus-client 0.26 тип по умолчанию — 1.0.0, поэтому `CONTENT_TYPE_PLAIN_0_0_4` задан явно. В выводе есть все 6 метрик из описания операции.
- Контрактный тест:
  - (а) спецификация валидна;
  - (б) хелпер ловит необъявленный статус, тело вне схемы и чужую операцию;
  - (в) каждая `operationId` сверяется по методу и пути, а в приложении нет операций сверх контракта.
- Операции берутся из `app.openapi()`. В FastAPI 0.143 `include_router` ленивый, и `app.routes` вложенных маршрутов не видит.
- Исправлен `tests/contract/helpers.py`: openapi-core не разбирал `application/problem+json`, и проверка любого ответа-ошибки падала. Добавлен десериализатор через `Config(extra_media_type_deserializers=…)`.

**T016.**
- Пароли хранятся в argon2id с перехэшированием при входе, если изменились параметры.
- Сессия:
  - токен случайный, в cookie `bm_session` с флагами `HttpOnly; SameSite=Strict; Path=/`, срок жизни 12 ч;
  - в БД лежит HMAC-SHA256(SESSION_SECRET, токен), а не сам токен;
  - CSRF-токен возвращают `login` и `me`, он сверяется на POST/PUT/PATCH/DELETE.
- Блокировка входа:
  - 10 неудач подряд закрывают вход на 15 минут (`429 login_locked` с `Retry-After`), даже с верным паролем;
  - успешный вход сбрасывает счётчик;
  - счётчик хранится в той же транзакции под `FOR UPDATE`;
  - для неизвестного логина выполняется фиктивная проверка хэша, чтобы время ответа не выдавало, есть ли такой логин.
- Первый администратор создаётся из `ADMIN_INITIAL_*` с `must_change_password=true`, только если пользователей нет. Создание идёт под advisory-блокировкой, потому что воркеров uvicorn два. Если пользователей нет и пароль не задан, сервис не стартует.
- `PERMISSIONS` — единственная таблица прав. Тест сверяет её с `x-roles` всех операций контракта.
- Общая зависимость `AdminSession` берёт `operationId` маршрута и проверяет:
  1. сессию;
  2. CSRF;
  3. `must_change_password` (до смены пароля доступны только `me`, `logout`, `changePassword`);
  4. роль.
- Отказ по роли — 403 и запись в аудит `forbidden_access` (actor, `operation`, operationId, метод и путь). Для объектов чужого подразделения есть `authorize_object(...)`.
- Аудит пишется для `login`, `login_locked`, `change_password` и создания первого администратора.

**T017.**
- `get_client(purpose, settings, *, transport=None)`:
  - `anthropic` и `openai` работают только при `IMPORT_ENABLED=true`, иначе `EgressDisabled`; только HTTPS и только свой хост;
  - `webhook` разрешён только на 10/8, 172.16/12, 192.168/16, 127/8 (имя хоста резолвится, все адреса должны быть частными) и только на свой хост и порт;
  - редиректы выключены, прокси из окружения игнорируются (`trust_env=False`);
  - параметр `transport` нужен для тестов коннекторов (T062, T063): MockTransport с фикстурами.
- В import-linter запрещены `httpx`, `urllib`, `http`, `socket` во всех пакетах `bm`, кроме `bm.egress`, включая `bm.main`, `bm.settings`, `bm.metrics`, `bm.clock`. Косвенные цепочки тоже проверяются, исключены только импорты внутри `bm.egress.client`.

**T018.**
- `ConfigSnapshot` содержит:
  - подразделения с разрешёнными моделями;
  - сотрудников с назначением на сегодня по МСК и всю историю назначений (для подписок по отрезкам);
  - лимиты;
  - каталог с текущей ценой (модели без действующей цены в каталог не попадают);
  - курсы;
  - ключи по SHA-256, включая отозванные с `active=False` — чтобы T021 отвечал 401;
  - неудалённые подписки.
- `load(conn, now)` читает снимок одной транзакцией REPEATABLE READ (если транзакции ещё нет), версию — первой.
- `SnapshotCache.ensure_fresh(conn, now)` делает ровно один запрос к `config_version` (тест считает запросы). Снимок перечитывается, если:
  - сменилась версия;
  - наступили новые сутки МСК;
  - вступила в силу цена с будущим `valid_from` (`valid_until`).
- `config.apply(conn, Change(action, object_type, run), actor)`: изменение, аудит и `config_version += 1` выполняются в одной транзакции. Исключение откатывает всё, вложенный вызов откатывается вместе с внешней транзакцией.

**T019.**
- `create_once(conn, kind, department_id, period, period_start, message) -> bool` работает через `ON CONFLICT ON CONSTRAINT notification_once DO NOTHING`. Тест: 8 параллельных соединений, создаёт ровно одно.
- `InApp` — канал по умолчанию: уведомление и есть строка в ленте.
- `listNotifications`:
  - admin видит всё, budget_owner — только своё подразделение (уведомления без подразделения ему не видны);
  - finance_viewer получает 403 с записью в аудит;
  - работают фильтр `unread` и пагинация до 200.
- `markNotificationRead`: «прочитано» хранится отдельно для каждого пользователя (`read_by`), повтор тоже отвечает 204. Чужое уведомление — 403 и аудит, несуществующее — 404.

### Отклонения от плана

1. **`get_client(purpose, settings, *, transport=None)`** вместо `get_client(purpose)` из `12_plan.md` §6. Настройки передаются явно, а не читаются из глобального состояния. `transport` нужен для тестов без сети.
2. **import-linter запрещает `urllib` и `http` целиком.** Подмодули внешних пакетов (`http.client`) import-linter запретить не может (ошибка «subpackages of external packages are not valid»). Следствие: в `bm` вне `egress` нельзя `urllib.parse` и `http.HTTPStatus`. Заголовки Problem взяты из своей таблицы в `errors.py`.
3. **`app/backend/pyproject.toml`: в per-file-ignores для `tests/**` добавлены `E501` и `S107`.** До моих задач `make lint` падал на 24 ошибках в уже существующих файлах T010–T014: длинные SQL и assert в тестах, пароль по умолчанию в `seed.admin_user`. Код приложения правился вручную, E501 для него остаётся в силе. Также прогнан `ruff format`: переформатированы 25 файлов, в том числе тесты T010–T014. Логика не менялась.
4. **Код ошибки `password_change_required`** (403) вне списка примеров `Problem.code`. Список в контракте открытый (`examples`), но фронтенду стоит о нём знать: на этот код показывать экран смены пароля.
5. **Неверный старый пароль в `changePassword` возвращает `422 invalid_credentials`, а не 401.** На 401 SPA посчитала бы, что сессия истекла, и выкинула пользователя.

### Вопросы техлиду

1. **Пробелы в контракте (менять его может только архитектор).** Сервер отдаёт статусы, которые в контракте не объявлены:
   - `logout`: 401 (нет сессии) и 403 (CSRF);
   - `changePassword`: 403 (CSRF);
   - `listNotifications`: 401 и 403 (finance_viewer по `x-roles`);
   - `markNotificationRead`: 401.
   Предлагаю объявить у всех операций с `security: session` ответы `401 Unauthorized` и `403 Forbidden`. Тогда `assert_matches_contract` можно применять и к отказным ответам. Сейчас в тестах такие ответы проверяются без хелпера.
2. **Флаг `Secure` у cookie.** Сейчас он не ставится: по умолчанию API слушает `127.0.0.1:8080` по HTTP. Если у заказчика будет HTTPS на обратном прокси, нужна переменная вроде `SESSION_COOKIE_SECURE=true`. Добавить её в `.env.example` (зона DevOps)?
3. **Срок сессии 12 ч** зашит константой (`SESSION_TTL`). В спецификации значения нет. Нужна ли переменная окружения?
4. **Прокси для коннекторов.** `trust_env=False` не даёт трафику уйти через прокси из окружения. Если в контуре заказчика к `api.anthropic.com` можно выйти только через корпоративный прокси, понадобится явная настройка `IMPORT_HTTPS_PROXY`. Решение за техлидом и архитектором.
5. **Ключ уникальности уведомлений с NULL** (`NULLS NOT DISTINCT`). Для уведомлений без периода (`import_failure`, `fx_missing`) вызывающий код T061/T071 должен передавать `period_start` (например, дату сбоя), иначе такое уведомление придёт один раз за всё время. Это описано в docstring `bm/notify/service.py`.
6. **Метрики при `UVICORN_WORKERS=2`** считаются в каждом процессе отдельно. Для `make load` (T086) понадобится multiprocess-режим prometheus-client или сбор по воркерам.

### Известные ограничения

- Хост webhook проверяется при создании клиента. Повторный резолв при соединении (DNS rebinding) не контролируется. Рекомендация для `admin-guide`: указывать IP-адрес.
- JSON-логи пока не настроены. Обработчик 500 пишет в журнал только класс ошибки, путь и метод. Общая настройка логирования — вместе с worker (T031).

## 2026-10-15 — Backend 2: T041, T042 (US3: загрузка AD, админ-CRUD) и доводка T016/T019 по 14_tech_rulings.md

**Итог.** T042 закрыта. T041 реализована полностью, но её критерий готовности ещё не выполнен: `test_removed_employee_keeps_period_spend` проходит до шага `getDepartmentBalance`, а эта операция появится в T071. Поэтому T041 в `12_tasks.md` не отмечена. После T071 тест станет XPASS(strict): нужно снять с него `xfail` и отметить T041.
`make test` (bm_test, `SKIP_FRONTEND=1`): **417 passed, 24 xfailed**, import-linter 3/3, `run-tests.sh full: OK`. `make lint` проходит.

### Что сделано

**T041 — загрузка AD-файла** (`importOrg`)
- `bm/org_import/service.py`: `import_ad_csv(conn, data, dry_run, actor, *, now) -> OrgImportSummary` и `parse(data)`.
  - Формат: UTF-8 (BOM допускается), разделитель `;`, заголовок `login;display_name;group;is_primary`.
  - Ошибка формата всего файла (кодировка, заголовок, пустой файл) → `422 validation_error`.
  - Ошибки строк попадают в сводку, номер строки — строка файла. Ошибка строки: нет логина или группы, ≠ 4 полей, `is_primary` не из `1/0/пусто`, повтор пары логин+группа, вторая отметка основной группы.
- Группа AD соответствует подразделению (`department.ad_group`). Новое подразделение создаётся с `policy_mode=observe`.
- Основная группа — строка с `is_primary=1`. Если отметки нет, берётся первая строка; при нескольких группах выдаётся предупреждение.
- Псевдоним `emp-` + 10 hex выдаётся один раз, при коллизии генерируется заново.
- Сотрудник, которого нет в файле: назначение закрывается, `employee.active=false`, личные лимиты и расход сохраняются. При возврате он получает новое назначение.
- Перевод: старое назначение закрывается вчерашним днём, новое начинается сегодня.
- `dry_run` выполняет ту же логику в транзакции и откатывает её, поэтому цифры сводки совпадают с реальной загрузкой. Запись в БД, аудит и `config_version` не меняются.
- Реальная загрузка идёт через `config.apply`. В аудите (`action=import`) — только числа сводки, без логинов. Параллельные загрузки сериализуются `pg_advisory_xact_lock`.
- 413 `file_too_large`: роутер читает не больше `MAX_FILE_BYTES + 1` (10 МиБ, константа), проверка выполняется до разбора файла (В6).
- `bm/http/routers/org.py` — `multipart/form-data` (`file`, `dry_run`).

**T042 — админ-CRUD.** Все 24 операции тегов departments (кроме двух операций баланса — T071), employees, models, fx, callers, admin-users.
- Ядро:
  - `bm/config/{departments,employees,catalog,callers,limits,errors}.py`, `bm/access/admin_users.py`;
  - роутеры `bm/http/routers/{departments,employees,models,fx,callers,admin_users}.py`;
  - схемы — отдельный модуль `bm/http/schemas_admin.py`;
  - преобразование ошибок ядра в Problem — `bm/http/admin_errors.py`.
- Все изменения идут через `config.apply`: аудит «было/стало» и `config_version += 1`.
- `revealPseudonym` пишет `reveal_pseudonym` (без `config_version`).
- Ключ вызывающей системы:
  - `bm_<prefix>_<secret>` показывается один раз, в БД хранится только SHA-256;
  - в аудите нет ни ключа, ни хэша;
  - повторный отзыв ничего не меняет и не пишет аудит.
- `createModel`/`createModelPrice`:
  - USD-цена без единого курса → `422 fx_rate_missing`;
  - `valid_from` в прошлом → 422;
  - `current_price` — последняя действующая цена, если её нет — ближайшая будущая.
- `updateAdminUser`:
  - `409 last_admin` (В6) — проверка под advisory-блокировкой в транзакции изменения;
  - `reset_password` и `active=false` закрывают сессии пользователя;
  - `reset_password` выставляет `must_change_password=true`.
- Подразделение у пользователя админки только для `budget_owner`, для него оно обязательно.
- Владелец бюджета видит только своё подразделение и его сотрудников. Чужой объект → 403 с записью `forbidden_access`.

**Доводка T016/T019 (14_tech_rulings.md Б1, Б2)**
- `SESSION_COOKIE_SECURE` (bool, по умолчанию `false`) в `bm/settings.py`. Флаг `Secure` ставится у `bm_session` при входе и при удалении cookie в `logout`. Тесты: `tests/unit/test_settings.py::test_session_cookie_secure_default_false_and_from_env`, `tests/integration/test_admin_crud.py::test_session_cookie_secure_flag_follows_setting[False|True]`.
- Отказные 401/403 в `tests/acceptance/test_auth.py` и `tests/integration/test_notify_once.py` проверяются через `assert_matches_contract`. Добавлен `test_must_change_password_on_real_admin_route` (403 `password_change_required` на `listDepartments`).
- Отказы новых роутеров проверяются так же: `test_new_routes_require_session` (401 по 8 операциям), CSRF 403, 403 владельца бюджета.
- Проверка (а) «спецификация 1.0.2 валидна» (`tests/contract`): 47 passed, 20 xfailed (PENDING других задач).

**Тесты Backend 2:** `tests/integration/test_admin_crud.py` — 35 тестов (cookie, 401/403, права владельца, 404/409/422, last_admin, сброс пароля, формат файла AD, BOM, повторы, обновление имени, observe у новых подразделений).

### Команды и вывод
```
$ DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test SKIP_FRONTEND=1 make test
================= 417 passed, 24 xfailed in 195.62s (0:03:15) ==================
Contracts: 3 kept, 0 broken.
run-tests.sh full: OK

$ make lint
Contracts: 3 kept, 0 broken.
All checks passed!
104 files already formatted

$ pytest tests/acceptance/test_us3_config.py tests/integration/test_admin_crud.py -rxX
XFAIL test_us3_config.py::test_removed_employee_keeps_period_spend - T071: getDepartmentBalance ...
XFAIL test_us3_config.py::test_3_5_new_price_from_15th_old_events_unchanged - дефект теста (QA) ...
53 passed, 2 xfailed

$ pytest tests/acceptance/test_us3_config.py -k "test_3_1 or test_3_2 or removed" --runxfail
E  assert 404 == 200      # test_us3_config.py:241 — GET /departments/{id}/balance (T071)
1 failed, 3 passed
```

### Изменения в общих и чужих файлах (точечные)
- `bm/main.py`: подключены 7 роутеров и `admin_errors.install(app)`. Правки Backend 1 (`caller`, `Budget`) не затронуты.
- `bm/http/routers/auth.py`, `bm/settings.py`: `SESSION_COOKIE_SECURE`.
- `app/backend/pyproject.toml` + `uv.lock`: прямая зависимость **`python-multipart==0.0.32`**. Без неё FastAPI не принимает `multipart/form-data` (`importOrg`). Раньше пакет приходил только транзитивно через extra `mcp`. Версия уже была в `uv.lock`, поэтому `uv lock` добавил две строки и ничего не обновил. Лицензия Apache-2.0 [Факт, метаданные пакета]. DevOps стоит учесть это в SBOM (T088).
- `tests/contract/helpers.py`: `assert_matches_contract` читает тело multipart-запроса через `req.read()` (httpx отправляет multipart потоком, `req.content` падал с `RequestNotRead`). Проверки не менялись.
- `tests/contract/test_openapi_contract.py`: операции T041/T042 убраны из `PENDING`, иначе получаем XPASS(strict).
- `tests/acceptance/test_us3_config.py`: модульный `xfail` снят. Точечный `xfail(strict)` остался у двух тестов (см. ниже). Проверки не менялись.

### Отклонения
1. **Ошибка 404 не объявлена у `listModelPrices` и `createModelPrice`.** Для неизвестной модели `listModelPrices` отвечает `200 {items: [], total: 0}`, а `createModelPrice` — `422` с `code=not_found`.
2. **Перевод и вывод сотрудника в тот же день, когда открыто назначение.** Назначение не закрывается, а удаляется, потому что CHECK `valid_to >= valid_from` и снимок T018 считают `valid_to` включительно. Иначе в один день действовали бы два назначения. Расход привязан к подразделению в момент решения (`call_record`/`ledger_daily`), поэтому история за неполные сутки не теряет денег. Изменение видно в аудите (`import`).
3. **Логин, который есть только в строках с ошибками, не выводится из подразделения.** Иначе опечатка в строке исключила бы человека. «Нет в файле» понимается как «логина нет ни в одной строке».
4. **Возврат выведенного сотрудника** считается в `employees_updated`, а не в `employees_added`: псевдоним и лимиты у него прежние.
5. **Сортировка списков** (`sort`) — по белому списку (`name`/`created_at` у подразделений, `id`/`provider`/`tie_order`/`created_at` у моделей). Другое поле → 422.
6. **Подразделения из импорта создаются для всех групп из строк без ошибок**, а не только для основных.

### Дефект приёмочного теста (для QA)
`test_3_5_new_price_from_15th_old_events_unchanged`: вход выполнен 14-го в 12:00, затем `clock.set(15-е 10:00)` — это 22 ч, а сессия живёт 12 ч (`SESSION_TTL`). Поэтому `GET /models/A/prices` получает 401, и тест падает с `KeyError: 'items'`. Остальные проверки теста (старая цена 14-го, новая 15-го, `fact_kop` не пересчитан) проходят. С повторным входом перед `GET /prices` (проверено на временной копии теста) тест проходит целиком. Предложение для QA: войти заново после `clock.set` или сдвинуть время меньше чем на 12 ч, затем снять `xfail`.

### Вопросы техлиду
1. Объявить в контракте `404` у `listModelPrices` и `createModelPrice` (см. отклонение 1)? Сейчас пришлось выбирать между 200/422 и необъявленным статусом.
2. Тестовая БД `bm_test` общая для параллельных разработчиков, а фикстура `db` пересоздаёт схему `public`. Совместный прогон даёт ложные падения: в базовом прогоне так упал `test_create_once_concurrent_single_winner`, при повторе он прошёл. Свои прогоны я вёл на отдельной `bm_test_b2` (создана рядом с `bm_test_b1`), финальный — на `bm_test`. Предлагаю закрепить отдельную БД за каждым исполнителем.
3. `deploy/.env.example` и руководство администратора: нужна переменная `SESSION_COOKIE_SECURE=false` (DevOps, T087/T090) — со стороны backend готово.

## 2026-10-15 — Backend 1: T021 (`Budget.decide`, роутеры вызывающей системы), T031 (`settle`, пакет, истечение резервов, баланс, worker)

**Итог.** T021 и T031 закрыты. Команды готовности обеих задач и `make test` на `bm_test` зелёные: **423 passed, 24 xfailed**. `make lint` проходит. Модульные `xfail` сняты во всех шести файлах приёмочных тестов T020/T030. Остались два точечных `xfail(strict)`: `test_subscriptions_over_100_percent_block_paid_calls` — это T051, его ставил QA; `test_decision_not_followed_charges_actual_model` — дефект засева в тесте, см. вопрос 1.

### Что сделано

| Задача | Файлы | Что |
|---|---|---|
| T021 | `bm/budget/service.py` (`Budget.authenticate`, `decide`, `integration_config`) | Алгоритм §4.5. Шаг 1 (субъект и `subject_scope`, отказ — 403 и аудит `forbidden_access`, actor `caller:<id>`) и шаг 9 (запись) — здесь; шаги 2–8 — `domain.select`. Транзакция: `FOR UPDATE` строк `budget_lock` в порядке (owner_type, owner_id) → один `SUM … FILTER` по `ledger_daily` → `select()` → `INSERT call_record` → `UPDATE budget_lock`. Резерв ложится и на сотрудника, и на подразделение. `decision_id` — UUIDv7 |
| T021 | `bm/budget/repo.py` | SQL горячего пути, `uuid7()`, `ensure_partitions` (под advisory-блокировкой) |
| T021 | `bm/budget/schemas.py`, `bm/budget/errors.py` | Pydantic-модели тега caller 1:1 с контрактом (`extra="forbid"`, токены — `StrictInt ≥ 0`); ошибки модуля с `status`/`code` контракта и `detail` на русском |
| T021 | `bm/http/routers/caller.py` | `createDecision`, `getIntegrationConfig` (ETag = хэш содержимого, 304 на `If-None-Match`; ключ с областью видит только своё подразделение) |
| T021 | `bm/http/deps.py` (дописан в конец) | `CallerDep` — аутентификация по `X-Api-Key`, `BudgetDep` |
| T021 | `tests/integration/test_decide_db.py` (9 тестов) | UUIDv7 и поля `call_record`; резерв в обоих `budget_lock`; deny → `closed` без резерва; окна периодов МСК (неделя через границу месяца); партиция на месяц часов при старте; `subject_scope` у ключей; ETag/304 |
| T031 | `bm/budget/service.py` (`settle`, `report`, `expire_reserves`, `caller_balance`, `balance`) | Идемпотентность по `report_key` (`INSERT … ON CONFLICT DO NOTHING`) и по статусу решения. Факт пишется в `ledger_daily` сотрудника и подразделения на дату решения, резерв снимается целиком — всё в одной транзакции, 200 отдаётся после COMMIT. Поздний отчёт после истечения пишет в реестр дельту «факт − оценка», флаг `no_report` сохраняется. `decision_not_followed` тарифицируется по цене фактической модели на момент решения. Отчёт без решения: дата расхода — `occurred_at` по МСК (не старше 7 суток и не дальше 5 мин в будущее), подразделение — по назначению на эту дату. Повтор (ключ, `report_id`) распознаётся до проверок (досылка из буфера через 8 суток — `duplicate`, а не 422) |
| T031 | `bm/http/routers/caller.py` | `reportUsage`, `reportUsageBatch` (> 1000 строк → 413 `batch_too_large` до разбора строк; каждая строка — своя транзакция, ошибки схемы и учёта — `ok=false` + `Problem` строки), `getCallerBalance` |
| T031 | `bm/worker/{jobs.py, main.py, __main__.py}` | `Scheduler`: у задачи свой интервал, `pg_try_advisory_lock(hashtext('bm.job.<имя>'))`, запись в `job_run` (ok/`error_class`), сбой задачи не останавливает цикл. Задачи: `expire_reserves` раз в 60 с, `call_record_partitions` раз в час. `python -m bm.worker`, остановка по SIGTERM |
| T031 | `bm/metrics.py` | Б6: при `PROMETHEUS_MULTIPROC_DIR` `/metrics` собирает все процессы через `MultiProcessCollector`; у gauge режим `mostrecent` задан явно |
| T031 | `tests/integration/test_worker_jobs.py` (3), `tests/unit/test_metrics.py` (3), `tests/integration/test_usage_rules.py` (6) | Планировщик и блокировка; два процесса пишут в один каталог → сумма; изоляция строк пакета, 403 + аудит для отчёта без решения, старый дубль, остаток ключа service, расход до перевода сотрудника |

TDD: `test_decide_db.py`, `test_worker_jobs.py` и `test_metrics.py` написаны первыми и падали (9 failed; 5 failed, 1 passed). `test_usage_rules.py` написан после реализации как регрессионный, он сразу зелёный.

### Команды и вывод (сокращённо)

```text
# до реализации
$ pytest tests/integration/test_decide_db.py                          9 failed
$ pytest tests/unit/test_metrics.py tests/integration/test_worker_jobs.py   5 failed, 1 passed

# готовность T021 (DATABASE_URL=…/bm_test)
$ pytest tests/acceptance/test_us1_decisions.py tests/acceptance/test_edge_cases.py tests/integration/test_concurrency.py
40 passed, 1 xfailed (T051) in 21.79s
# + test_messages_ru.py проходит полностью (в составе make test)

# готовность T031
$ pytest tests/acceptance/test_us2_usage.py tests/integration/test_settle_db.py
26 passed, 1 xfailed (вопрос 1) in 19.46s

$ DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test SKIP_FRONTEND=1 make test
БД доступна: PostgreSQL 16.15
423 passed, 24 xfailed in 151.47s
Contracts: 3 kept, 0 broken.
run-tests.sh full: OK

$ make lint
Contracts: 3 kept, 0 broken. / All checks passed! / 105 files already formatted

$ python -m bm.worker   (SESSION_SECRET задан, 4 с, затем SIGTERM)
worker_started → reserves_expired → worker_stopped, exit=0; job_run: expire_reserves ok, call_record_partitions ok
```

Самые долгие тесты: пакет из 1000 строк — 3,4 с, 3 × 50 конкурентных решений — 1,6 с.

### Изменения в общих и чужих файлах (точечные)
- `bm/main.py`: в lifespan создаётся `app.state.budget = Budget(...)` (договорённость QA, `tests/fixtures/qa.py::expire_reserves`) и вызывается `ensure_partitions()` на месяц часов приложения; подключён `caller.router`.
- `bm/http/deps.py`: дописан блок `CallerDep`/`BudgetDep`/`budget_problem`, две строки импорта и docstring. Остальное не тронуто.
- `tests/contract/test_openapi_contract.py`: пять операций caller убраны из `PENDING`.
- Тесты QA: в `test_us1_decisions.py`, `test_edge_cases.py`, `test_messages_ru.py`, `test_concurrency.py`, `test_us2_usage.py`, `test_settle_db.py` снят модульный `xfail`, docstring поправлен. Одному тесту добавлен точечный `xfail(strict)` с причиной (вопрос 1). Проверки не менялись.

### Отклонения
1. **Схемы caller лежат в `bm/budget/schemas.py`, а не в `bm/http/schemas.py`** (план §6). `Budget` принимает и возвращает их сам, а import-linter (контракт adapters-thin) запрещает ядру импортировать `bm.http`. MCP (T081) берёт их оттуда же.
2. **Методы `Budget` сами берут соединение из пула**, сигнатуры — как в плане (`decide(cmd, caller)`). Соединение-зависимость FastAPI здесь не используется: при пуле в 10 соединений и 50 одновременных запросах два соединения на запрос привели бы к взаимной блокировке пула.
3. **Ключ, которого нет в снимке, проверяется одним запросом к `caller_system` по индексу SHA-256.** Новый ключ действует сразу, даже если снимок ещё не перечитан (так требует `test_decision_of_other_caller_is_404`, где ключ засевается прямым INSERT). Отзыв идёт через `config.apply`, поднимает версию и действует сразу.
4. **Подписки в остатке = 0** до T051 (шов — `Budget._states`, поле `amort`). Уведомление `reservation_no_report` при истечении резерва не создаётся — это T071.
5. **USD-курс в решении**: курс месяца, а если его нет — последний известный до него. Если курса нет вообще, модель-кандидат пропускается, а для запрошенной модели возвращается 422 `fx_rate_missing` (статус 422 у `createDecision` объявлен).
6. **`expense_date` отчёта без решения** — дата `occurred_at` по МСК. Подразделение берётся по назначению на эту дату (история `employee_assignment`).

### Вопросы техлиду
1. **Дефект засева в `test_us2_usage.py::test_decision_not_followed_charges_actual_model` (для QA).** Фикстура `w` задаёт подразделению дневной лимит 10 000 ₽. `spend(db, "department", w.dep, 9_998_000)` кладёт 99 980 ₽ на **сегодня**, поэтому дневной остаток −89 980 ₽. По §4.5 п. 5 применяется самый строгий лимит, и итог — `deny budget_exceeded`, а не `redirect` на C, как ожидает тест (C стоит 5 ₽, бесплатной модели нет). Если засеять `day=TODAY - timedelta(days=1)`, тест проходит целиком (проверено на временной копии). Предлагаю QA поправить засев и снять `xfail`.
2. **`policy_mode` в решении `subject_unknown`, когда у ключа нет подразделения** (`any_employee`). Поле обязательно, а подразделения нет. Отдаю `enforce` (исход — отказ в любом режиме), `fail_mode` = `DEFAULT_FAIL_MODE`, `department_id = null`. Устраивает?
3. **`decision_not_followed`: куда писать фактическую модель.** В `call_record` нет колонки для неё. Сейчас `final_model` перезаписывается фактической моделью: `requested_model` и флаг сохраняются, а модель из решения теряется. Нужна ли колонка `actual_model` (новая миграция) для отчётов T071?
4. **Коды 422 для отчёта без решения:** неизвестный субъект — `subject_unknown`, неизвестная модель — `model_unknown`, нет курса — `fx_rate_missing`. В `Problem.code` это только примеры, не enum, поэтому контракт не нарушается. `getCallerBalance` без `login` для ключа не-service → 404 `subject_unknown`.
5. **`over_limit` и `used_pct` в `LimitBalance`:** `over_limit = remaining < 0` (с учётом резервов), `used_pct = (лимит − остаток) / лимит`, один знак, ROUND_HALF_UP; при лимите 0 — `0.0` или `100.0`. Нужно подтверждение для T071/T072.
6. **Gauge `reservations_open`** выставляет worker, а `/metrics` отдаёт `api`. Без общего каталога multiprocess (или без расчёта в `api`) этот gauge в `/metrics` не виден. Решение для DevOps (T087): общий `tmpfs` у `api` и `worker`? Или убрать gauge из worker и считать в `api`?
7. **Формат журналов.** `python -m bm.worker` использует `logging.basicConfig` с уровнем из `LOG_LEVEL`. Общего JSON-форматтера в проекте пока нет. Чья это задача (T087?)?
8. **Отдельная тестовая БД.** Итерации шли на `bm_test_b1` (создана мной, `CREATE DATABASE` прошёл), финальный прогон — на `bm_test`. Поддерживаю предложение Backend 2 закрепить отдельную БД за каждым исполнителем.

## 2026-10-19 — Backend 1: T033 (эталонный клиент `budget_client`)

**Статус:** T033 закрыта по первой части критерия готовности (`pytest tests/unit/test_client_buffer.py`). Вторая часть, `make up && make failover`, ждёт T087 и Docker: демон не запущен, отказные тесты T032 без `BM_FAILOVER=1` пропускаются (2 skipped).

### Что сделано
- `app/client/budget_client/` — отдельный пакет: `pyproject.toml` (`dependencies = []`, Python ≥ 3.11, сборка — hatchling, MIT), `README.md`, а также `budget_client/{__init__.py, client.py, buffer.py, config_cache.py, transport.py}`.
- **Зависимости:** только stdlib (`http.client`, `sqlite3`, `json`, `threading`). Сторонних пакетов нет, поэтому белый список лицензий и транзитивная телеметрия не затрагиваются.
- **Сеть:** только к хосту и порту из `base_url` (http/https). `http.client` не читает `HTTP(S)_PROXY`, это закреплено тестом. Телеметрии нет. Ключ API на диск не пишется (тест).
- **`decide()`:** общий срок запроса 50 мс (соединение, отправка и ответ вместе), keep-alive по соединению на поток. Если переиспользованное соединение оказалось мёртвым, выполняется один повтор, пока срок не истёк.
  - Сбой (таймаут, нет соединения, 5xx, 408/429, испорченный ответ) обрабатывается по `fail_mode` субъекта: `open` → `ClientDecision(outcome="allow", fail_open=True)`, `closed` → `PolicyUnavailable` (`code="policy_unavailable"`).
  - Ответы 401/403/404/422 поднимают `ClientRequestError`, см. отклонение 2.
- **Кэш** (`config_cache.py`): `integration-config`, ETag и `fail_mode` по субъекту из ответов `decide` лежат в JSON на диске. Запись атомарная (tmp + `os.replace` + fsync) и только при изменении.
  - Обновление раз в `refresh_s` (60 с) через `If-None-Match`; на 304 обновляется только отметка времени.
  - Порядок выбора `fail_mode`: (1) более свежая из двух записей — последнее решение или конфигурация подразделения субъекта; (2) для ключа `service` — его единственное подразделение; (3) `default_fail_mode`; (4) `open`, если утилита ни разу не ответила (принцип III).
  - Кэш переживает перезапуск процесса вызывающей системы.
- **Буфер** (`buffer.py`): SQLite, `journal_mode=WAL`, `synchronous=FULL`.
  - Ключ — `report_id` (UNIQUE, `INSERT OR IGNORE`); `seq` задаёт порядок.
  - Состояния: `pending` и `rejected` — построчная 4xx от сервера, строка уходит в карантин и не блокирует очередь.
- **`report(*, decision_id, tokens, call_status, **kw)`:** `kw` — `report_id` (задаёт вызывающий, по ожиданию QA; если нет — UUID4), `subject`, `model`, `occurred_at` (по умолчанию время вызова), `actual_model`.
  - Отчёт сначала записывается в буфер (COMMIT с fsync), затем будится фон.
  - Без `decision_id` обязательны `subject` и `model`.
- **`flush(max_batch=500, max_retries=5) -> int`:**
  - Отправляет пакеты по 500 в `/usage/batch`. При сбое пакета делает паузы 0,5 → 1 → 2 → … с (не больше 30 с), не больше 5 повторов подряд; неотправленное остаётся в буфере.
  - Возвращает число строк, принятых сервером (`charged` и `duplicate`).
  - Отправляются только строки, записанные до начала вызова, поэтому под потоком `flush()` завершается.
  - Явный `flush()` и фон взаимно исключены замком, строка уходит один раз (тест: 800 строк → ровно 800 отправок).
- **Фон** (поток-демон, `background=True` по умолчанию): обновляет конфигурацию раз в 60 с и досылает буфер после `report()`. Отчёты, пришедшие в пределах 50 мс, собираются в один пакет. Если досылка не удалась, следующая попытка — через растущую паузу (не больше 60 с). Есть `close()` и контекстный менеджер.

### Проверка
```
$ uv run ... pytest tests/unit/test_client_buffer.py -q
37 passed in 5.97s
$ DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test_b1 SKIP_FRONTEND=1 make test
478 passed, 83 xfailed in 294.68s ... Contracts: 3 kept, 0 broken ... run-tests.sh full: OK
$ ruff check / ruff format --check (app/client, tests/unit/test_client_buffer.py)
All checks passed! / 7 files already formatted
$ pytest tests/failover -q          # без BM_FAILOVER=1, Docker не запущен
2 skipped
```
- Мутационная проверка: `synchronous=NORMAL`, `BATCH_SIZE=600` и `PAUSE_BASE_S=1.0` роняют 4 теста; после отката зелёные.
- **Эмуляция SC-002 без Docker** (скрипт в scratchpad, не в репозитории): настоящий `bm` под uvicorn на loopback, БД `bm_test_b1`, данные через `tests.failover.stack.provision`. Поток 2 × 10 rps в течение 20 с, на 5-й секунде API получает SIGKILL и до конца потока лежит. Затем подъём и `flush()`.
  - Итог: open в окне отказа — 149/149 `fail_open`; closed в окне отказа — 149/149 `PolicyUnavailable`; иных исключений нет.
  - Фон 5 раз пытался дослать с паузами и отступил. После подъёма `flush()` дослал 150 из 150; в `report_key` из 250 `report_id` пропущено 0, дублей 0.
  - p95 пары `decide`+`report` — 11,2 мс (одна машина, `report` с fsync).
- **`make lint`: exit 1, но не из-за T033.** 5 ошибок ruff (I001, F401, UP017) в чужих файлах, которые сейчас пишет QA: `tests/acceptance/test_us5_import.py`, `test_us6_reports_roles.py`, `tests/integration/test_import_pipeline.py`. Мои файлы чистые. В одном из трёх прогонов `make test` был 1 failed. Он не воспроизвёлся, и в это время соседи меняли тесты; по T033 падений нет.

### Отклонения
1. **Добавлен модуль `transport.py`** (HTTP на `http.client`) сверх перечня файлов задачи. Он изолирует сеть и общий срок запроса.
2. **4xx на `decide` → `ClientRequestError`, а не fail-open.** Это следует ADR-005 (ошибки запроса и доступа — не сбой). Иначе отозванный ключ или неверный запрос молча превращались бы в fail-open: при `closed` вызовы шли бы без контроля. Сбоем считаются только 408 и 429.
3. **`report()` возвращает `report_id` (str), а не `None`**, как в плане §6. Это совместимо: вызывающий может не задавать `report_id` и всё равно знать ключ.
4. **Таймаут досылки (10 с на пакет) и `integration-config` (2 с) отличается от 50 мс.** 50 мс относится к пути решения; пакет из 500 строк за 50 мс не обрабатывается. Значения задаются параметрами конструктора.
5. **`timeout_ms` из `integration-config` клиент не применяет:** действует значение конструктора (по умолчанию 50).

### Вопросы техлиду / QA / DevOps
1. **QA (T032): прогрев в SC-002 может мигать.** Первое решение после подъёма или подготовки данных у холодного API заняло 55 мс (замер httpx), то есть больше 50 мс. Тогда `warm.fail_open=True`, и assert прогрева падает до начала теста. Предлагаю в прогреве повторять `decide` до ответа без `fail_open` (до N раз). В эмуляции так и сделано: хватило одной попытки.
2. **DevOps (зона `Makefile`):** `make lint` не охватывает `app/client`. Предлагаю добавить `app/client` в пути `ruff check/format` целей `lint` и `fmt`. Сейчас проверено вручную тем же конфигом.
3. **DevOps / T088:** включить `app/client/budget_client` в SBOM (пакет без зависимостей) и описать в `docs/integration-guide.md` (T090) права на `state_dir`. В буфере лежат логины субъектов (ПДн), ключа там нет.

## 2026-10-20 — Backend 1: T051 (подписки и амортизация в остатке), T061 (конвейер импорта и справочник источников)

**Итог.** T051 и T061 реализованы, пометки `xfail(T051)`, `xfail(T061)` и общая `T051 + T061` (SC-007) сняты, проверки не менялись. `pytest tests/acceptance/test_us4_subscriptions.py` — 15 passed. Все тесты T060 на `RecordedSource` проходят. Полный `make test` на `bm_test_b1` даёт 549 passed, 12 xfailed и 14 failed. Все 14 падений — `XPASS(strict)` у пометок **T071**: код Backend 2 (отчёты, баланс подразделения, журналы) уже лежит в дереве, и эти тесты проходят. Снимать пометки T071 — часть «Готово» T071, поэтому я их не трогал. Других падений нет. import-linter: 3 kept, 0 broken.

### Что сделано
| Задача | Файлы | Суть |
|---|---|---|
| T051 | `bm/budget/subs.py` (новый) | Чьи подписки: сотрудника — ему и подразделению по отрезкам `employee_assignment`; «не распределено» — никому. M месяца берётся только из `subscription_month`; если строки нет, M считается по курсу месяца или последнему введённому (`last_known_rate_used`) и фиксируется при первом расчёте (`ON CONFLICT DO NOTHING`). Амортизация окна — через `domain.amortize`. Доля подписок считается за весь период (FR-020), `notify_shares` создаёт `subs_share` |
| | `bm/budget/service.py` | `_amort` → `LimitState.amort` в `decide` и `balance`. В `balance` M фиксируется до read-only транзакции. Прочитанные M кэшируются в процессе (они неизменяемы). Добавлено свойство `Budget.pool` |
| | `bm/config/subscriptions.py`, `bm/http/routers/subscriptions.py`, `bm/http/schemas_subs.py` | 6 операций через `config.apply` (аудит, `config_version`). USD без единого курса → `422 fx_rate_missing`. При создании фиксируется M по текущий месяц и проверяется доля |
| | `bm/worker/jobs.py` | Задача `subscriptions_new_period` раз в 5 минут, срабатывает с 00:05 МСК: фиксирует M текущего месяца и заново проверяет долю (дублей нет за счёт `create_once`) |
| T061 | `bm/provider_import/{pipeline.py, catalog.py, runs.py, sources/base.py, sources/recorded.py}`, `bm/http/routers/{provider_sources.py, imports.py}` | `pipeline.run(pool, source, day_from, day_to, now)`. Загрузка у провайдера идёт вне транзакции. Запись — в одной транзакции под advisory-блокировкой провайдера: upsert по (provider, source_ref, model, day), статус по текущему справочнику, в `ledger_daily` подразделения уходит дельта «новое − старое». Строка без курса сохраняется с `amount_kop = NULL`. Уведомления `import_failure` (после 2 неудач подряд) и `import_unallocated` создаются с `period_start` = дата МСК (Б5). Справочник: `409 source_exists`, `422 unsupported_source_kind`. Статус, журнал запусков, `runImport` → 202 `queued`, 409 `import_disabled` / `provider_key_missing` |
| | `bm/notify/service.py`, `tests/unit/test_notify_key.py` | `create_once(period_start=None)` → `ValueError` (Б5) |
| | `bm/worker/jobs.py` | `import_jobs(budget, settings)`: такт раз в 5 минут — сначала очередь ручных запусков, затем плановая загрузка с `IMPORT_HOUR_MSK` и повтор раз в час до `IMPORT_RETRY_UNTIL_HOUR_MSK`, окно `IMPORT_WINDOW_DAYS`. При `IMPORT_ENABLED=false` такт сразу завершается. Коннектор подгружается по имени модуля (T062/T063): если модуля нет, ручной запуск получает `failed/internal` |

Правки тестов (только снятие пометок и договорённости из `tests/fixtures`): `xfail` в `test_us4_subscriptions.py`, `test_edge_cases.py::test_subscriptions_over_100_percent…`, `test_us5_import.py` (модуль), `test_import_pipeline.py`, `test_sc007_reference_balance.py` (модуль), `test_secrets_not_leaked.py::test_import_api_never_returns_keys`; T051 и T061 убраны из `PENDING` в `tests/contract/test_openapi_contract.py`. В `tests/fixtures/qa.py::worker_tick` теперь передаётся `app.state.settings` в `default_jobs`, как предусмотрено договорённостью QA №2: без настроек нет задачи импорта.

### Команды (сокращённо)
```text
$ pytest tests/acceptance/test_us4_subscriptions.py
15 passed in 18.67s
$ DATABASE_URL=…/bm_test_b1 SKIP_FRONTEND=1 make test
14 failed, 549 passed, 12 xfailed in 231.90s   # 14 = XPASS(strict) пометок T071 (проверено -rX: 14)
$ lint-imports → Contracts: 3 kept, 0 broken
$ ruff check / format --check по моим файлам — чисто
```
`make lint` целиком красный из-за файлов Backend 2 в работе: `reports/*`, `notify/thresholds.py`, `logging.py`, `metrics.py`, `http/routers/{audit,events,reports,departments}.py`, строка `notifications` в `worker/jobs.py`, `tests/unit/test_logging.py`. Ошибки — E501, I001 и формат. В моих файлах ошибок нет.

### Отклонения
1. **Удаление подписки** ставит `end_date = сегодня`, а `deleted_at` не ставит. Существующий тест T018 (`test_deleted_subscriptions_excluded`) требует, чтобы снимок не видел строк с `deleted_at`, а прошедшие дни должны оставаться в остатке. Ещё не начавшаяся подписка при удалении стирается целиком вместе со строками `subscription_month`. Удаление видно в аудите (`action=delete`).
2. **Задача подписок запускается ежедневно с 00:05**, а не только 1-го числа. Новый период дня или недели — тоже «наступление нового периода» (сценарий 4.4). Ключ `create_once` даёт одно уведомление на период.
3. **Курс для строк импорта:** курс месяца даты расхода, а если его нет — последний введённый до него. Так же считает `Budget._rate`. Если курса нет совсем, строка сохраняется с `amount_kop = NULL`.
4. **`finished_at` запуска импорта = `now` такта**, а не реальное время окончания: у `pipeline.run` нет часов, сигнатура взята из договорённости QA.

### Вопросы техлиду
1. **Вопросы QA о подписках (15_qa_report.md):** (а) доля подписок считается за весь период — реализовано так, как проверяют тесты QA; (б) `endSubscription` датой в прошлом **запрещён** (422), как и повторное открытие уже закончившейся подписки: иначе менялась бы амортизация прошедших дней (4.5). Тестом это не закреплено; (в) «не распределено» по прошедшим дням — это отчёт T071 (Backend 2), моя часть тут не задействована. Подтвердите (а) и (б).
2. **T071 / Backend 2:** когда T071 будет закрыта, снять пометки T071 в `test_us5_import.py` (2 теста), `test_sc007_reference_balance.py` (1), `test_us3_config.py` (1), `test_us6_reports_roles.py` (5) и `PENDING_MARK` в `test_roles_matrix.py` (5). Сейчас все они дают XPASS. После этого `make test` будет зелёным.
3. **Импорт без коннекторов (до T062/T063):** при `IMPORT_ENABLED=true` плановая загрузка пропускается с записью `import_connector_missing` в журнал, ручной запуск завершается `failed/internal`. Нужен ли отдельный код в статусе — или это закрывает T062?

## 2026-10-20 — Backend 2: T071 (отчёты, баланс подразделения, журналы, фоновые задачи), закрытие T041

**Итог:** T071 и T041 отмечены `[x]`. `SKIP_FRONTEND=1 make test` на `bm_test_b2`: **583 passed, 11 xfailed**, import-linter 3/3 KEPT, exit 0. `make lint`: exit 0.

### Что сделано
- **Баланс подразделения:** `getDepartmentBalance`, `listDepartmentBalanceItems` (`bm/http/routers/departments.py`). Остаток считается через `Budget.balance`, то есть по тем же правилам, что getCallerBalance и пороги; амортизация из T051 подхватывается автоматически. Для `at` в прошлом периоды, которые уже закончились, показываются без открытых резервов. Прослеживаемость: строки `token` (call_record), `reservation` (открытые резервы, только в текущем периоде), `import` (import_line `charged`), `subscription` (по подписке, через `bm.budget.subs`). Финансист получает `subject_pseudonym = null`.
- **LimitBalance по В1-5** (`Budget._limit_balance`): `used_pct` и `over_limit` считаются по расходу без резервов. Тесты — `tests/unit/test_limit_balance.py`.
- **Отчёты** (`bm/reports/service.py`, `bm/http/routers/reports.py`):
  - `getSpendReport` — `group_by` department/model/source/day/month; `department_id=unallocated`; флаг `late`; модель берётся по `final_model` (В1-3). Токены за дни старше самой старой партиции читаются из `agg_daily`.
  - `getSpendCsv` — UTF-8 с BOM, разделитель `;`, строка на (месяц, подразделение, модель, источник, валюта), защита от CSV-инъекции (`'` перед `= + - @ \t \r`), без сотрудников.
  - `getReconciliation` — источники `decision_api` против событий ключей, связанных с источником. Сутки UTC; есть `diff_pct` и `coverage_pct`.
  - Владелец бюджета получает чужое подразделение или `unallocated` → 403 и аудит.
- **Журналы:** `listEvents` (фильтры outcome/code/flag/department, у владельца — только своё подразделение) и `listAudit` (`bm/http/routers/{events,audit}.py`).
- **Фоновые задачи** (`bm/worker/jobs.py::report_jobs`, добавляются в `default_jobs`; `settings` — необязательный параметр, worker его передаёт):
  - `notifications` раз в минуту (`bm/notify/thresholds.py`):
    - пороги 80/100% по `used_pct`;
    - `fx_missing` с ключом `period_start` = 1-е число месяца, только если нужен USD;
    - `reservation_no_report`: подразделение плюс дата МСК истечения резерва (Б5);
    - при заданном `WEBHOOK_URL` статус уведомления — `webhook_status=pending`.
  - `agg_daily` раз в сутки: 8 последних суток до вчера, токены и импорт.
  - `retention` раз в сутки (`bm/reports/maintenance.py`):
    - партиции на 2 месяца вперёд;
    - партиции старше `RETENTION_DETAIL_MONTHS` перед `DROP` сворачиваются в `agg_daily`;
    - заодно удаляются `report_key` того же возраста, `agg_daily` старше `RETENTION_AGG_MONTHS` и `job_run` старше 90 суток.
- **Журналы JSON** (`bm/logging.py`, stdlib):
  - одна строка JSON с полями `ts`, `level`, `logger`, `msg` и белым списком дополнительных полей;
  - исключение пишется только классом;
  - значения `*_ADMIN_KEY`, `IMPORT_HTTPS_PROXY` (вместе с логином и паролем из URL), `SESSION_SECRET` и начального пароля маскируются;
  - уровень берётся из `LOG_LEVEL`;
  - подключено в `create_app` и в `worker/main.py`.
- **Gauge `reservations_open` удалён** (В1-6): изменены `bm/metrics.py` и `Budget.expire_reserves`; `tests/unit/test_metrics.py` и `tests/integration/test_system.py` проверяют, что метрики нет.
- **T041:** с `test_removed_employee_keeps_period_spend` снят xfail, тест проходит.
- **Снятые пометки xfail:**
  - модульная T071 в `test_us6_reports_roles.py`;
  - `@T071` в `test_us5_import.py` (2) и `test_sc007_reference_balance.py` (1);
  - `PENDING_MARK` в `test_roles_matrix.py` — `PENDING` пуст;
  - T071 в `PENDING` контрактного теста.
  Проверки не менялись.
- **Новые тесты:** `tests/unit/test_logging.py` (6), `tests/unit/test_limit_balance.py` (6), `tests/integration/test_reports.py` (11), `tests/integration/test_report_jobs.py` (8).

### Команды
```
DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test_b2 SKIP_FRONTEND=1 make test
  583 passed, 11 xfailed in 262.51s; Contracts: 3 kept, 0 broken; run-tests.sh full: OK
pytest tests/acceptance/test_us6_reports_roles.py tests/security tests/acceptance/test_us3_config.py::test_removed_employee_keeps_period_spend
  53 passed, 5 xfailed
make lint → exit 0 (141 files already formatted)
```
Оставшиеся 11 xfail: 9 относятся к T062/T063, а также 2 точечные пометки в `test_us6_reports_roles.py` — см. вопросы 1 и 2 ниже.

### Отклонения
1. **`tests/contract/helpers.py`** (файл QA, правка точечная): добавлен десериализатор `text/csv`. openapi-core не декодирует `text/csv` и сверял bytes со схемой `type: string`, поэтому любой корректный CSV не проходил проверку.
2. Пороги считаются только для лимитов **подразделений**: так сказано в FR-029, а в `notification` нет поля сотрудника.
3. Журнал доступа uvicorn приглушён (WARNING): в строке запроса может быть `login` сотрудника (ПДн). Длительность запросов видна в `/metrics`.
4. Строка CSV для подписки: модель пустая. Исходная сумма для USD = ₽ / курс M месяца.
5. Задачи `agg_daily` и `retention` начинаются при старте worker и дальше идут раз в сутки (`every = 1 день`), а не в фиксированный час.

### Вопросы техлиду
1. **Дефект засева QA:** `test_6_2_csv_injection_is_neutralized` создаёт сотрудников `user1`, `user2` после первого решения и не вызывает `bump_config`. Снимок конфигурации (T018) их не видит, отсюда `subject_unknown`. Тест помечен точечным `xfail` с этой причиной; та же проверка CSV-инъекции зелёная в `tests/integration/test_reports.py::test_csv_neutralizes_formula_prefixes`. QA: добавить `bump_config(db)` после засева и снять пометку.
2. **T061 (Backend 1):** `createProviderSource` и `updateProviderSource` не пишут `audit_log` (FR-031), поэтому `test_6_5_audit_records_who_when_before_after` помечен точечным `xfail` с причиной T061. Снять пометку после исправления.
3. **Аудит изменений через `config.apply` (T042):** время записи берётся из БД (`now()`), а не из `Clock`. В проде это одно и то же, но в тестах с `FrozenClock` дата аудита не совпадает с замороженной. Переводить ли `apply` на `Clock`?
4. **Зависимость от модуля Backend 1:** отчёты и прослеживаемость используют публичные функции `bm.budget.subs` (`charged_to`, `needed_months`, `month_totals`, `amount`, `Charged`). Если Backend 1 меняет их сигнатуры, нужно сообщить Backend 2.

## 2026-10-21 — Backend 1: аудит справочника источников (3Б6), T062 (коннектор Anthropic + `IMPORT_HTTPS_PROXY`), T063 (коннектор OpenAI), T091 (руководство по интеграции)

### Что сделано
- **3Б6, первый шаг T062.** Записи аудита создавались и раньше: `provider_import/catalog.py` шёл через `config.apply`. Дефект был в другом: время бралось из `now()` БД, и при `FrozenClock` записи не попадали в фильтр `listAudit`. Теперь `create/update/delete` получают `now` от `Clock` (роутер `provider_sources.py`, `ClockDep`) и передают `at=now` в `apply`. Новый тест `tests/integration/test_provider_sources_audit.py` (2) проверяет `before`/`after`, `at` = замороженное время, `config_version += 3`, а также что отклонённое изменение в аудит не пишется. Красная фаза: `r["at"] == now` → False. Точечную пометку с `test_6_5` я сначала переназначил на 3Б7: остаток падения давал `updateAdminUser`, зона Backend 2. Backend 2 закрыл 3Б7 и снял пометку, теперь `test_6_5` зелёный без `xfail`.
- **`IMPORT_HTTPS_PROXY` (Б4).**
  - `bm/settings.py`: поле `SecretStr | None`, по умолчанию пусто. Схема только `http(s)://` с хостом, иначе ошибка старта на русском. Разбор через `pydantic.AnyUrl`, потому что `urllib` в `bm.settings` запрещён import-linter'ом. В `model_config` включён `hide_input_in_errors=True`: в ошибке старта нет значений, в том числе пароля прокси и ключей.
  - `bm/egress/client.py`: явный `proxy=` только для `anthropic`/`openai`, у `webhook` его нет никогда. `trust_env=False` остаётся. При `IMPORT_ENABLED=false` — `EgressDisabled` до создания клиента.
  - Тесты (`tests/security/test_no_egress.py`, +7; `tests/unit/test_settings.py`, +9): пусто → без прокси; задан → прокси у `anthropic` и `openai`, у `webhook` нет; флаг выключен → 0 соединений; запрос при заданном прокси даёт единственную попытку соединения — к `192.0.2.10:3128` (прокси), белый список хостов не изменился; стандартные `HTTPS_PROXY`/`ALL_PROXY` игнорируются; пароля прокси нет в журнале.
- **T062** — `bm/provider_import/sources/anthropic.py` и общий `sources/_http.py`: пагинация, классы ошибок, `Decimal` из JSON. Тесты — `tests/integration/test_anthropic_source.py` (25), включая импорт через недоступный прокси: `failed/provider_unavailable`, пароля и ключа нет в журнале и дампе БД. Пометки `@T062` сняты в `test_us5_import.py` (4) и `test_secrets_not_leaked.py` (3); проверки не менялись.
- **T063** — `bm/provider_import/sources/openai.py`. Тесты — `tests/integration/test_openai_source.py` (20). Пометка `@T063` в `test_us5_import.py` снята.
- **T091** — `docs/integration-guide.md`: протокол, `http_status_hint`, коды отказов и 422/404 (В1-2, В1-4), эталонная схема 50 мс / fail-open / буфер, пример на `budget_client`, закрытие прямого доступа к провайдерам, `state_dir` (права, ПДн, ключа нет), «MCP в v1 не поставляется» (3К, 3Б9). Описание сверено с кодом сервера и клиента.

### Допущения о форматах провайдеров (сверки со спайком не было)
- **Anthropic `GET /v1/organizations/cost_report` — формат НЕ сверен** [Гипотеза]. В SDK `anthropic` 1.15/1.16 этого эндпоинта Admin API нет: там только beta `/v1/organizations/analytics/cost_report` (Enterprise, другой набор `group_by`). Из SDK подтверждаются только названия `starting_at`/`ending_at`/`bucket_width`/`page` и массив `group_by[]` со скобками [Факт]. Принято:
  1. `amount` — десятичная строка **в центах**, ₽ = /100;
  2. `currency = USD`, иначе `bad_response`;
  3. модель — поле `model`, если нет — из `description` («Claude Opus 4.1 Usage - …» → `claude-opus-4-1`), иначе `cost_type`, иначе `unknown`;
  4. `workspace_id = null` → источник `default`;
  5. сутки — дата `starting_at` (UTC);
  6. заголовок `anthropic-version: 2023-06-01`.

  Ошибка в п. 1 даёт расход, завышенный или заниженный в 100 раз. Её нужно проверить на первом реальном ответе.
- **OpenAI `GET /v1/organization/costs`** — параметры и структура ответа сверены с типами SDK `openai` 3.35.1: `UsageCostsParams`, `UsageCostsResponse`, `array_format="brackets"` → `group_by[]=…` [Факт]. Не сверено [Гипотеза]: модель = часть `line_item` до запятой (снапшот с датой, например `gpt-4o-2024-08-06`, не приводится к имени каталога); `project_id = null` → `default`; `amount = null` → строки нет.
- Классы ошибок для обоих: 401/403 → `auth_rejected`; 408/429/5xx и сетевые ошибки, включая прокси, → `provider_unavailable`; прочие 4xx, не JSON, неверная структура, NaN, повторяющийся курсор, больше 1000 страниц → `bad_response`. Ключ не задан → `auth_rejected` без запроса. В тексте `ImportFailed` — только статус или класс исключения.

### Команды
```
pytest tests/integration/test_provider_sources_audit.py   # до правки: 1 failed (at != Clock), после: 2 passed
pytest tests/security/test_no_egress.py tests/unit/test_settings.py   # до: 13 failed; после: 51 passed (вместе с test_logging)
pytest tests/integration/test_anthropic_source.py          # до: 25 x ModuleNotFoundError; после: 70 passed (с settings/egress)
pytest tests/integration/test_openai_source.py tests/acceptance/test_us5_import.py   # до: 19 failed; после: 42 passed
pytest tests/acceptance/test_us6_reports_roles.py          # 7 passed, 1 xfailed (SEED_DEFECT QA, 3Б5)

DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test_b1 SKIP_FRONTEND=1 make test
  1 failed, 720 passed, 1 xfailed in 211.20s
  FAILED tests/deploy/test_compose_static.py::test_database_url_has_no_password   (файл DevOps, см. вопрос 1)
make lint-imports → Contracts: 3 kept, 0 broken
make lint → ruff check: 1 ошибка E501 в deploy/ci/check_licenses.py:158; ruff format: deploy/ci/check_licenses.py,
            tests/deploy/test_compose_static.py — оба файла DevOps (в работе). Мои файлы: ruff check/format чистые.
```

### Отклонения
1. `bm.egress.client` реэкспортирует `Client`, `Transport`, `TransportError` (псевдонимы httpx). Пакетам вне `egress` импорт httpx запрещён, а коннекторам нужны тип транспорта и класс сетевых ошибок. Контракт import-linter не менялся.
2. Если передан тестовый `transport`, прокси не монтируется: httpx отправил бы запрос через смонтированный прокси мимо подмены. Наличие прокси проверяется на клиенте без транспорта.
3. В `Settings` включён `hide_input_in_errors=True` для всех полей, а не только для прокси. Тексты ошибок старта остаются, значения не печатаются.
4. T091 **не отмечена `[x]`**: её критерий — «техлид принял документ».

### Вопросы техлиду
1. **`make test` красный из-за теста DevOps, не из-за кода backend.** `tests/deploy/test_compose_static.py::test_database_url_has_no_password` запускает `docker compose config`, а `make test` экспортирует тестовый `DATABASE_URL` (Makefile, `export DATABASE_URL`). Compose подставляет его вместо значения по умолчанию. Без `DATABASE_URL` в окружении — 37/37 passed, с ним — 1 failed. DevOps: вызывать compose с очищенным окружением (`env -u DATABASE_URL` или `env=` в subprocess). Пока это не исправлено, `make test` красный у всех исполнителей.
2. **Формат Anthropic `cost_report`** (единицы `amount`) — главный риск T062. Нужен один записанный ответ с реального ключа заказчика, после этого заменить синтетические фикстуры. Предлагаю внести это в чек-лист приёмки (T090/T089) как НЕ ПРОВЕРЕНО.
3. Межмодульный интерфейс (3Б8): сигнатуры `bm.provider_import.catalog.create/update/delete` получили обязательный аргумент `now`. Вызывает их только роутер `provider_sources.py`, Backend 2 это не затрагивает.

## 2026-10-21 — Backend 2: T073 (webhook-канал), первый шаг — время аудита по `Clock` (3Б7)

**Итог:** T073 отмечена `[x]`. `SKIP_FRONTEND=1 make test` на `bm_test_b2`: **720 passed, 1 xfailed, 1 failed**. Упал только `tests/deploy/test_compose_static.py::test_database_url_has_no_password`. Это тест DevOps, к T073 он не относится: Backend 1 описал его выше, вопрос 1. Если запустить его без `DATABASE_URL` в окружении — 37/37 passed. `make lint`: import-linter 3/3 KEPT. ruff падает только на `deploy/ci/check_licenses.py:158` (E501, файл DevOps). По всем моим файлам `ruff check` и `ruff format --check` чистые.

### Что сделано
- **3Б7 — время аудита берётся из `Clock`:**
  - `audit.write(..., at)` и `config.apply(..., at)` — аргумент `at` теперь обязательный, `coalesce(now())` убран. `DEFAULT now()` у колонки остался;
  - `now` передаётся из `clock.now()` роутера: `departments` (create, update, limits), `admin_users` (create, update), `employees` (limits, `reveal_pseudonym`);
  - `forbidden_access` (`bm/http/deps.py`) берёт время через `get_clock(request)`;
  - вход в систему, импорт AD, справочник источников (Backend 1) и остальные справочники уже передавали `at`.
- **T073 — webhook:**
  - `bm/notify/service.py`: добавлена `configure(webhook_enabled=…)`. Её вызывают lifespan api и `worker.run` по `WEBHOOK_URL`; при выходе из lifespan значение сбрасывается в `disabled`. У `create_once` `webhook_status=None` означает «по настройке процесса», поэтому `subs_share`, `import_failure`, `import_unallocated` и остальные виды получают `pending`, и модули Backend 1 менять не пришлось. Пороги по-прежнему передают статус явно.
  - `bm/notify/channels.py`:
    - `Webhook` — клиент только через `egress("webhook")`;
    - отправка — POST JSON с полями `id`, `kind`, `department_id`, `period`, `period_start`, `message`, `created_at` (время МСК, ISO 8601);
    - 3 попытки с паузами 1 и 2 с, тайм-аут попытки 5 с; 2xx — `delivered`, иначе `failed`;
    - `deliver_pending` за один такт берёт до 20 уведомлений `pending`; статус меняется только из `pending`.
  - `bm/worker/jobs.py`: задача `webhook` раз в минуту, стоит последней в `default_jobs`. Если `WEBHOOK_URL` пуст, задачи нет.
  - Если адрес не проходит `egress` (публичный IP), возникает `EgressForbidden`, его класс пишется в `job_run.error_class`. Уведомления остаются `pending`: после исправления адреса они будут доставлены. Соединений 0.
- **Тесты** (сначала красные — вывод ниже):
  - `tests/integration/test_audit_clock.py` (6): `config.apply` (подразделение, лимиты, пользователь админки), справочник источников, вход, `reveal_pseudonym`, `forbidden_access`, импорт AD — `at` равно `FrozenClock`, запись видна в `listAudit` за замороженный день; вызов без `at` даёт `TypeError`;
  - `tests/integration/test_webhook.py` (9), получатель — локальный HTTP-сервер на 127.0.0.1:
    - все 7 видов получают `pending`, после lifespan — снова `disabled`;
    - доставка и формат тела; повторной отправки нет;
    - 500/503/302 дают `failed` после 3 запросов;
    - 500, 500, 204 дают `delivered`;
    - получатель не слушает порт — `failed`;
    - сквозной такт worker (порог → `webhook` → `delivered`) — в теле нет псевдонима, логина, ФИО и id сотрудника;
    - публичный адрес — `EgressForbidden` и запись в `job_run`;
  - `tests/integration/test_webhook_disabled.py` (2): `WEBHOOK_URL` пуст — у всех видов `disabled`, задачи `webhook` нет, 0 соединений;
  - снят `xfail` `CLOCK_AUDIT` с `test_6_5_audit_records_who_when_before_after` (его поставил Backend 1 под 3Б7). В `test_reports.py::test_audit_lists_changes_with_before_after` интервал до 2099 заменён замороженным днём и точным `at`.

### Команды и вывод (сокращённо)
```
# красная фаза
pytest tests/integration/test_audit_clock.py            → 4 failed, 2 passed (источники и импорт AD уже передавали at)
pytest tests/integration/test_webhook.py                → ERROR collecting: module 'bm.notify.channels' has no attribute 'Webhook'
# зелёная
pytest tests/integration/test_audit_clock.py            → 6 passed
pytest tests/integration/test_webhook.py tests/integration/test_webhook_disabled.py → 11 passed
# мутация: убран notify.configure в lifespan api       → test_webhook.py: 6 failed (возвращено)
# готовность T073
DATABASE_URL=…/bm_test_b2 SKIP_FRONTEND=1 make test     → 1 failed, 720 passed, 1 xfailed in 210s
  FAILED tests/deploy/test_compose_static.py::test_database_url_has_no_password (DevOps, DATABASE_URL из окружения)
env -u DATABASE_URL pytest tests/deploy/test_compose_static.py → 37 passed
make lint → Contracts: 3 kept, 0 broken; ruff: E501 deploy/ci/check_licenses.py:158 (DevOps)
```
Оставшийся xfail — `test_6_2_csv_injection_is_neutralized` (дефект засева QA, 3Б5, T093).

### Изменения в общих и чужих файлах (точечные)
- `tests/acceptance/test_us6_reports_roles.py` (QA, правил Backend 1): удалён маркер `CLOCK_AUDIT` — так и предполагала его пометка «снимает Backend 2».
- `tests/integration/test_snapshot.py`: в `apply` передаётся `at=AUDIT_AT`.
- `bm/main.py`, `bm/worker/main.py`: вызов `notify.configure`.

### Отклонения
1. Статус по умолчанию для новых уведомлений — настройка процесса (`configure`), а не параметр, передаваемый по цепочке. Иначе пришлось бы менять `bm.budget.subs` и `bm.provider_import.pipeline` (модули Backend 1, сейчас в работе).
2. Все 3 попытки делаются в одном такте, с паузами 1 и 2 с. Колонку для счётчика попыток и миграцию не добавлял. Худший случай для одного уведомления — около 18 с; за такт обрабатывается не больше 20 уведомлений.
3. Ответ 3xx считается неудачей: редиректы `egress` не выполняет.

### Для DevOps (T090, `docs/admin-guide.md`, раздел «Webhook»)
Формат тела: `{"id","kind","department_id"|null,"period"|null,"period_start"|null,"message","created_at"}`, `Content-Type: application/json`, метод POST на `WEBHOOK_URL` (путь и query сохраняются). Успех — любой 2xx. Повторы: 3 попытки (паузы 1 и 2 с, тайм-аут 5 с), затем `failed`. Задача — раз в минуту. Публичный адрес — `job_run.error_class=EgressForbidden`, уведомления ждут в `pending`.

### Вопросы техлиду
1. `make test` красный у всех исполнителей из-за `test_compose_static.py` (DevOps), то же, что вопрос 1 Backend 1. Принимается ли готовность T073 с этим единственным посторонним падением?
2. Пункт 2 «Отклонений»: устраивают ли повторы внутри такта, или нужны попытки в разных тактах (колонка `webhook_attempts`, миграция 0002)?

## 2026-10-21 — Backend 2: T096 (админка из образа и бюджет такта webhook; 14_tech_rulings.md, пакет 4, 4Д6 и 4Б4)

**Статус:** T096 — `[x]` по `make test`. Часть готовности «`compose_only`-тест `test_admin_spa_served_from_image` в журнале CI для релизного SHA» в этой среде не проверить: Docker нет, она подтверждается в T092.

### Что сделано
- **Раздача админки (4Д6), `bm/main.py`.**
  - Новая константа `ADMIN_STATIC_DIR = Path("/app/static/admin")`. Новый параметр `create_app(..., admin_dir=ADMIN_STATIC_DIR)`. Переменной окружения нет.
  - Каталог есть — монтируется `StaticFiles(directory=admin_dir, html=True)` на `/admin`. Каталога нет — монтирования нет, в журнал пишется одна строка `info` `admin_static_disabled`, API работает.
  - `StaticFiles` импортируется из `fastapi.staticfiles` (это реэкспорт Starlette). Новых зависимостей нет, `uv.lock` не менялся.
  - Как ведут себя пути: `/admin` → 307 на `/admin/`; `/admin/` отдаёт `index.html` (`text/html`); ассеты отдаются по `base: '/admin/'`; отсутствующий файл → 404, подмены на `index.html` нет.
  - Контрактный тест T015 строит маршруты из `app.openapi()`, а в эту схему `Mount` не попадает. Поэтому исключать что-то из сверки не понадобилось, и это закреплено отдельным тестом `test_static_mount_not_in_contract_schema`.
- **Бюджет такта webhook (4Б4), `bm/notify/channels.py`.**
  - Новая константа модуля `TICK_BUDGET_S = 30.0`.
  - У `Webhook` новый параметр `monotonic` (по умолчанию `time.monotonic`), его можно подменить в тестах.
  - Как работает `deliver_pending`: время старта такта фиксируется до создания клиента. Перед каждым уведомлением проверяется `elapsed ≥ 30 с` → `break`. Уведомление, которое уже начали отправлять, доводится до конца. Необработанные остаются `pending`, по ним пишется строка `info` `webhook_tick_budget` с их числом.
  - HTTP-запрос и раньше выполнялся вне транзакции: соединение берётся только на `SELECT` очереди и на `UPDATE` статуса (autocommit), перед `send` оно возвращено в пул. Код переносить не пришлось, это закреплено тестом (см. ниже).

### Тесты (TDD: красная фаза → зелёная)
- `tests/integration/test_admin_static.py` (новый, 15 тестов):
  - `/admin/` → 200 `text/html`; `/admin/assets/app.js` → 200; `/admin` → 307 на `/admin/`;
  - `/admin/nope.js` и `/admin/departments/1` → 404;
  - `/admin/../bm/settings.py` через httpx → 404;
  - 5 сырых ASGI-путей в обход нормализации httpx (`..`, `%2e%2e`, `assets/../../`, `..%2f`) к файлам рядом с каталогом → 404, содержимое не отдаётся;
  - `/healthz`, `/readyz`, `/metrics` и `/api/v1/auth/me` (401 `problem+json`) работают;
  - без каталога: `/admin/` → 404, `/healthz` → 200, в журнале ровно одна строка `info`;
  - значение `admin_dir` по умолчанию — `/app/static/admin`.
- `tests/integration/test_webhook.py`, добавлено 3 теста. Часы `FakeTime`: пауза и каждая попытка (через новый хук `Receiver.on_request`) двигают монотонные часы на `TIMEOUT_S`, реального ожидания нет.
  - Получатель отвечает 500, в очереди 5 `pending`. Одно уведомление занимает 3×5 + 1 + 2 = 18 с. Такт 1 обрабатывает 2 уведомления (в 36 с: второе начато в 18 с и доведено до конца), остаются 3 `pending`. Такты 2 и 3 обрабатывают 2 и 1. В итоге все 5 `failed`, запросов 15.
  - В момент каждого HTTP-запроса в `pg_stat_activity` нет соединений в состоянии `idle in transaction`. Мутационная проверка: если обернуть `send` в `conn.transaction()`, тест падает (`{1} == {0}`); код после проверки восстановлен.
  - Быстрый получатель: уходят все 5 за такт.
  - Граница: ровно 30 с к началу следующего уведомления → оно не берётся.
- Красная фаза: `6 failed, 9 passed, 12 errors`. Причины — `TypeError` (нет `admin_dir` и `monotonic`) и отсутствие `ADMIN_STATIC_DIR` и `TICK_BUDGET_S`.

### Команды и вывод
```
$ DATABASE_URL=postgresql://bm:bm@127.0.0.1:5432/bm_test_b2 SKIP_FRONTEND=1 make test
======================= 766 passed in 454.06s (0:07:34) ========================
Contracts: 3 kept, 0 broken.
vitest: пропущен (SKIP_FRONTEND=1)
run-tests.sh full: OK          (exit 0)

$ make lint
ruff check: All checks passed!
ruff format --check: 1 file would be reformatted — tests/unit/test_settings.py   (exit 2)
Contracts: 3 kept, 0 broken.
```
`make lint` красный, и только из-за `tests/unit/test_settings.py`. Это файл Backend 1, который сейчас идёт в T097, его я не трогал. Мои файлы проходят `ruff check` и `ruff format --check`.

### Отклонения
- Тест «HTTP-запрос вне транзакции» проверяет `pg_stat_activity`, а не перехватывает соединения пула. Так проверяется само требование: нет открытой транзакции на время запроса.
- В `Receiver` из `test_webhook.py` добавлен необязательный хук `on_request`. Остальные тесты файла его не используют.

### Для DevOps (4Д9, п. 3)
В `admin-guide.md` §10 можно писать: «за такт отправляется не больше уведомлений, чем укладывается в 30 с; начатое уведомление доводится до конца (до ≈ 48 с), остальные — в следующем такте».

### Вопросы техлиду
1. Подтвердите, что T096 закрыта по `make test`, а проверка `compose_only` переходит в T092. Если нет — верните T096 в `[ ]`.

## 2026-10-21 — Backend 1: T097 (`IMPORT_HTTPS_PROXY_FILE`; 14_tech_rulings.md, пакет 4, 4Д4)

### Что сделано
- `bm/settings.py`: `import_https_proxy` добавлен в `_FILE_SECRETS`, новое поле `import_https_proxy_file: Path | None`.
- Чтение `<ИМЯ>_FILE` перенесено из `after`-валидатора в `before`-валидатор (вместе с правилом «пусто — не задано»). Поэтому:
  - файл имеет приоритет над `<ИМЯ>`, пустой файл означает «не задано» (прямой выход);
  - проверка схемы `http(s)://` (`_proxy_url`) действует и для значения из файла. Раньше файлы читались после валидаторов полей, и значение из файла прошло бы без проверки [Факт по коду];
  - если файл указан, но не читается (нет файла, нет прав, каталог), старт падает с ошибкой `IMPORT_HTTPS_PROXY_FILE: не удалось прочитать файл <путь> (FileNotFoundError); …`. Значения секретов в тексте нет, путь показывается (это не секрет).
- Попутно найден и закрыт тестом дефект: обязательный `session_secret` нельзя было передать **только** через `SESSION_SECRET_FILE` — pydantic падал с `Field required` раньше, чем читался файл [Факт: проверено запуском до правки]. А compose передаёт `api`/`worker` именно `SESSION_SECRET_FILE` (`deploy/docker-compose.yml:26`). Теперь работает (`test_session_secret_from_file_only`).
- Тесты: `tests/unit/test_settings.py` (+5 функций: приоритет файла, пустой файл, схема из файла ×3, файла нет, `SESSION_SECRET_FILE` без `SESSION_SECRET`); `tests/security/test_no_egress.py` (+3: прокси из файла у `anthropic`/`openai`, у `webhook` его нет, пароль прокси из файла не попадает в журнал и соединение идёт только к прокси).

### Команды и вывод (сокращённо)
- Красная фаза: `pytest tests/unit/test_settings.py tests/security/test_no_egress.py` → `9 failed, 47 passed` (тесты пустого файла и webhook до правки зелёные, так и должно быть).
- Зелёная: тот же набор → `56 passed`.
- `DATABASE_URL=…/bm_test_b1 SKIP_FRONTEND=1 make test` → `766 passed in 333.89s`, `Contracts: 3 kept, 0 broken`, `run-tests.sh full: OK`. Первый прогон дал 5 failed и 12 errors в `test_admin_static.py`/`test_compose_static.py`: Backend 2 и DevOps в это время правили свои зоны. Отдельный прогон этих файлов → `53 passed`, повторный полный прогон зелёный.
- `make lint` → `Contracts: 3 kept, 0 broken`, `All checks passed!`, `165 files already formatted`.

### Отклонения
- Кроме добавления в `_FILE_SECRETS` изменён порядок чтения файлов (`before` вместо `after`). Без этого не выполнить требование «проверка схемы для значения из файла». Поведение для остальных секретов прежнее, плюс исправлен `SESSION_SECRET_FILE`.

### Для DevOps (T087/T090)
- В `deploy/docker-entrypoint.sh` переменная `IMPORT_HTTPS_PROXY_FILE` уже добавлена в цикл снятия пустых `*_FILE` [Факт: видно в текущем файле]. Это обязательно: без этого при пустом прокси (compose файл не создаёт) старт `worker` падал бы с новой ошибкой «не удалось прочитать файл».

### Вопросы техлиду
1. Принять исправление `SESSION_SECRET_FILE` в рамках T097 или оформить его отдельной строкой в `16_release.md` как найденный дефект поставки?

## 2026-10-21 — Backend 2: T098, часть Backend 2 (Д-1: TCP_NODELAY у `api` при нескольких воркерах; 14_tech_rulings.md, пакет 5, 5Д1–5Д2)

Статус: часть Backend 2 выполнена, в `12_tasks.md` отмечена подпунктом `[x]`. Общий `[x]` у T098 ставится после части DevOps и приёмки QA (повтор T086, 5Д2).

### Итог в числах (loadavg 0,1–0,4, БД `bm_test_b2`, 2 воркера)
| Замер | Прежняя команда `uvicorn … --workers 2` | `python -m bm.serve` |
|---|---|---|
| Регресс-тест: keep-alive `GET /healthz`, медиана запросов 2–31 | 43,95 мс (мин 42,09, макс 47,97) — FAIL | 0,45 мс (мин 0,35, макс 2,78) — PASS |
| 200 решений эталонным `budget_client`, `timeout_ms=50` (по умолчанию) | `fail_open` 15 из 200 (7,5%); медиана 48,00 мс, p95 51,08, p99 51,41 | `fail_open` 0 из 200; медиана 4,33 мс, p95 6,65, p99 9,39, макс 11,95 |

[Факт] Замеры выше сделаны на этой машине, это не эталонный стенд. SC-001 по 5Д2 подтверждает QA полным 10-минутным `make load`.

### Что сделано
- `app/backend/bm/serve.py` (новый) — точка запуска `python -m bm.serve`:
  - `NoDelayH11Protocol(H11Protocol)` объявлен на уровне модуля. В `connection_made` он ставит `TCP_NODELAY=1` на сокет транспорта, если это AF_INET или AF_INET6, и затем вызывает базовый метод. Unix-сокет и транспорт без сокета пропускаются. `OSError` от `setsockopt` не роняет соединение;
  - `main()` вызывает `uvicorn.run("bm.main:create_app", factory=True, host, port, workers, http=NoDelayH11Protocol, server_header=False)`. `--host` и `--port` передаются аргументами командной строки, по умолчанию `0.0.0.0` и `8080`, как в прежнем `CMD`. Число воркеров берётся из `UVICORN_WORKERS`: если переменная пуста или не задана — 2; если значение не целое или меньше 1 — выход с понятной ошибкой;
  - в блоке `__main__` функция `main` берётся из импортированного `bm.serve`. Так в uvicorn уходит класс `bm.serve.NoDelayH11Protocol`, а не `__main__.…`: воркеры запускаются через spawn и ищут класс по имени модуля.
- `Config.bind_socket`, `Multiprocess` и asyncio не подменяются. Новых зависимостей и переменных окружения нет. Тайм-аут `budget_client` не менялся.
- `tests/unit/test_serve.py` проверяет:
  - на TCP-сокете с `proto=0` флаг ставится;
  - на AF_UNIX и без сокета ничего не падает;
  - класс живёт в `bm.serve`;
  - `main()` по умолчанию совпадает с прежним `CMD`;
  - хост и порт берутся из аргументов, число воркеров — из env;
  - плохие значения `UVICORN_WORKERS` отклоняются.

  Случай AF_INET6 в этой среде пропущен (`skip`: IPv6 недоступен).
- `tests/integration/test_keepalive_latency.py` (только Linux) запускает `python -m bm.serve --host 127.0.0.1 --port <свободный>` с `UVICORN_WORKERS=2` и БД из `DATABASE_URL`. Клиент — одно `http.client.HTTPConnection` без TCP_NODELAY: 1 прогревочный и 30 подряд `GET /healthz`. Проверка: медиана < 10 мс. Порт своего `api` на время теста добавляется в `conftest.ALLOWED_ENDPOINTS`, как в `test_webhook.py`.

### Согласование «той же команды» с DevOps (T099)
Общая команда — `python -m bm.serve --host <адрес> --port <порт>`, число воркеров берётся из `UVICORN_WORKERS`.
- `CMD` образа: `["python", "-m", "bm.serve", "--host", "0.0.0.0", "--port", "8080"]`.
- `stack.sh`: `"$VENV/bin/python" -m bm.serve --host 127.0.0.1 --port "$API_PORT"`.
- Регресс-тест: константа `SERVE_CMD` с той же формой.

Отдельный скрипт не понадобился: вся логика запуска (флаги uvicorn, `server_header=False`, воркеры) живёт в `bm.serve.main()`, снаружи остаются только хост и порт. То, что `CMD` и `stack.sh` не вызывают `uvicorn` напрямую, проверяет статический тест DevOps `tests/deploy/test_image_supply.py`. Файлы DevOps я не трогал.

### Красная и зелёная фазы (повтор 21:33, loadavg 0,31)
- Красная фаза. Временная копия теста, в `SERVE_CMD` стоит прежняя команда `python -m uvicorn bm.main:create_app --factory --host 127.0.0.1 --port <p> --workers 2 --no-server-header`. После прогона копия удалена:
  ```
  keep-alive GET /healthz, воркеров 2: медиана 43.95 мс, мин 42.09, макс 47.97 (n=30)
  E       AssertionError: медиана 43.95 мс ≥ 10.0 мс: похоже на Д-1 (нет TCP_NODELAY на сокетах api)
  1 failed in 2.75s
  ```
  До появления модуля `test_serve.py` падал на `ImportError: cannot import name 'serve' from 'bm'`.
- Зелёная фаза:
  ```
  keep-alive GET /healthz, воркеров 2: медиана 0.45 мс, мин 0.35, макс 2.78 (n=30)
  11 passed, 1 skipped in 1.32s
  ```

### 200 решений эталонным `budget_client` (5Д1, проверка в T098)
Использован скрипт вне репозитория (scratchpad). Схема БД `bm_test_b2` перед каждым прогоном пересоздаётся. Скрипт поднимает `api` прежней или новой командой с 2 воркерами на свободном порту 127.0.0.1. Подготовка данных — `tests.failover.stack.provision(("open",))`: подразделение `enforce` с `fail_mode=open` и сервисный ключ. Затем `BudgetClient(base_url, key, state_dir)` без `timeout_ms` (проверено `timeout_ms == 50`), 1 прогревочное решение и 200 решений `decide({"type": "service"}, …)` подряд.
```
uvicorn: решений 200, fail_open 15, исходы {'allow': 200}, timeout_ms 50; медиана 48.00 мс, p95 51.08, p99 51.41, макс 51.63; loadavg 0.11
serve:   решений 200, fail_open 0,  исходы {'allow': 200}, timeout_ms 50; медиана 4.33 мс,  p95 6.65,  p99 9.39,  макс 11.95; loadavg 0.34
```
С исправлением — 0 `fail_open` по тайм-ауту, критерий 5Д1 выполнен. Здесь у клиента медиана 4,33 мс против 0,45 мс у `/healthz`: в неё входит само решение (БД, резерв). [Вывод] Запас до тайм-аута 50 мс — больше 4× по p99.

### Полный прогон и lint
- `DATABASE_URL=…/bm_test_b2 SKIP_FRONTEND=1 make test`: `797 passed, 1 skipped in 256.26s`, `Contracts: 3 kept, 0 broken`, rc=0. Пропущен только AF_INET6.
- `make lint`: `All checks passed!`, `172 files already formatted`, `Contracts: 3 kept, 0 broken`.
- Предыдущий прогон (21:33–21:37) дал `5 failed, 785 passed`. Упали `tests/deploy/test_ci_annotations.py` (3) и `tests/deploy/test_image_supply.py` (2, digest), `make lint` нашёл 3 ошибки в `deploy/ci/gha.py`. Это правки T099, которые DevOps вносил в тот момент, к T098 они не относятся. После того как файлы DevOps перестали меняться, `tests/deploy` дал `81 passed`, а полный прогон и lint — зелёные (см. выше).

### Отклонения
- Хост и порт передаются аргументами `--host`/`--port`, а не через `BIND_ADDR`/`API_PORT`. В compose эти переменные означают адрес публикации на хосте, а контейнер всегда слушает `0.0.0.0:8080`. Новых переменных нет, как требует 5Д1.

### Вопросы техлиду
Нет.

## 2026-10-21 — Backend 2: T098, дефект первого старта на пустой БД (CI 92b3414, первый `make smoke` FAIL)

**Итог.** Причина — гонка в раннере миграций, а не в `bm.serve`. В `bm/db/migrate.py` `CREATE TABLE IF NOT EXISTS schema_migrations` выполнялся до `pg_advisory_lock`. Если на пустой схеме два процесса одновременно выполняют `CREATE … IF NOT EXISTS`, PostgreSQL отвечает одному из них `UniqueViolationError: duplicate key value violates unique constraint "pg_type_typname_nsp_index"`. Падает lifespan воркера, и uvicorn останавливает весь `api` (`Child process failed to start, stopping the parent process`). Исправление: создание `schema_migrations` перенесено под advisory-блокировку. Теперь весь DDL раннера выполняется под ней.

### Как найдено (systematic-debugging)
- Остальные шаги lifespan уже под блокировками: `ensure_initial_admin` — `pg_advisory_xact_lock`, `ensure_partitions` — `pg_advisory_xact_lock`. Без блокировки оставался только `CREATE TABLE IF NOT EXISTS schema_migrations` в `migrate()`. Его вызывают оба воркера `api` и `worker` (`bm/worker/main.py`).
- Сквозное воспроизведение: `python -m bm.serve`, 2 воркера, схема `bm_test_b2` пересоздаётся перед каждым стартом, проверка `/healthz`. Упал 1 из 10 стартов (run 3). Трейс:
  ```
  bm/db/migrate.py, line 24, in migrate … asyncpg.exceptions.UniqueViolationError: duplicate key value violates
  unique constraint "pg_type_typname_nsp_index"  DETAIL: Key (typname, typnamespace)=(schema_migrations, …) already exists.
  Application startup failed. Exiting.
  ```
- Гонка зависит от времени: на старом коде в следующих сериях упало 0 из 25 стартов и с `bm.serve`, и с `uvicorn --workers 2`. [Вывод] Порядок старта `bm.serve` не меняет: обе команды идут через один и тот же `uvicorn.Multiprocess` (spawn), и обе уязвимы. То, что на 899cf1e первый smoke прошёл, — удача по времени, а не свойство старой команды. В CI на пустой БД параллельно с `api` стартует ещё и контейнер `worker` (3 претендента).

### Регресс-тест (TDD) — `tests/integration/test_migrate_concurrent.py` (новый)
- `test_migrate_runs_no_ddl_before_advisory_lock` — детерминированный. Тест держит блокировку миграций, `migrate()` на другом соединении за 0,3 с не должен создать `schema_migrations`, после снятия блокировки применяет миграции.
- `test_parallel_first_migrate_on_empty_schema`: 15 раундов по 4 параллельных `migrate()` на пустой схеме. Ни одной ошибки; миграции применяет ровно один процесс.
- Красная фаза (до исправления):
  ```
  E   AssertionError: migrate() создаёт schema_migrations до advisory-блокировки — гонка первого старта
  E   AssertionError: параллельный первый migrate() упал: UniqueViolationError('duplicate key value violates unique constraint "pg_type_typname_nsp_index"')
  2 failed in 0.93s
  ```
- Зелёная: `test_migrate_concurrent.py` + `test_migrations.py` — `16 passed in 5.42s`.
- Сквозная проверка после исправления: 0 из 30 первых стартов `python -m bm.serve` (2 воркера) упали; для сравнения `uvicorn --workers 2` — 0 из 25.

### Полный прогон
- `DATABASE_URL=…/bm_test_b2 SKIP_FRONTEND=1 make test`: `799 passed, 1 skipped in 240.34s`, `Contracts: 3 kept, 0 broken`, rc=0.
- `make lint`: `All checks passed!`, `173 files already formatted`, `Contracts: 3 kept, 0 broken`. Перед этим `ruff` нашёл длинную строку в docstring `migrate()`. Её перенёс, после чего повторил `make lint` и два теста миграций; полный `make test` после правки текста не повторял.

### Вопросы техлиду
- Нужна приёмка: повтор CI-цепочки `make up` → первый `make smoke` на пустой БД (DevOps/QA). Локально стек в Docker не проверить.
